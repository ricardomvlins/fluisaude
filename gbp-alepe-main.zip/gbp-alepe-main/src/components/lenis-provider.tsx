"use client"

import { useEffect, useRef } from "react"
import Lenis from "lenis"

export function LenisProvider({ children }: { children: React.ReactNode }) {
    const lenisRef = useRef<Lenis | null>(null)

    useEffect(() => {
        const scrollContainers = document.querySelectorAll("main")
        if (scrollContainers.length === 0) return

        const main = scrollContainers[0] as HTMLElement
        const lenis = new Lenis({
            wrapper: main,
            content: main.firstElementChild as HTMLElement || main,
            smoothWheel: true,
            lerp: 0.08,
            duration: 1.2,
            wheelMultiplier: 0.8,
            touchMultiplier: 1.5,
            infinite: false,
        })

        lenisRef.current = lenis

        function raf(time: number) {
            lenis.raf(time)
            requestAnimationFrame(raf)
        }
        requestAnimationFrame(raf)

        return () => { lenis.destroy(); lenisRef.current = null }
    }, [])

    return <>{children}</>
}
