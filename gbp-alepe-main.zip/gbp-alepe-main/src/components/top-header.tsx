"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { Search, Bell, X, LogOut, Settings, User, ChevronDown } from "lucide-react"
import { notificacoes } from "@/lib/mock-data"
import { ThemeToggle } from "@/components/theme-toggle"
import Link from "next/link"

export function TopHeader() {
    const [showNotif, setShowNotif] = useState(false)
    const [showUser, setShowUser] = useState(false)
    const [readIds, setReadIds] = useState<string[]>([])
    const router = useRouter()
    const unread = notificacoes.filter(n => !n.lida && !readIds.includes(n.id)).length

    const markRead = (id: string) => setReadIds(p => [...p, id])
    const markAllRead = () => setReadIds(notificacoes.map(n => n.id))
    const logout = () => { localStorage.removeItem("gbp_auth"); localStorage.removeItem("gbp_token"); router.push("/login") }

    return (
        <header className="sticky top-0 z-20 flex h-12 shrink-0 items-center justify-between gap-4 border-b border-border bg-background/80 backdrop-blur-xl px-4">
            <div className="flex items-center gap-3 flex-1 min-w-0">
                <SidebarTrigger className="-ml-1 text-muted-foreground hover:text-foreground transition-colors h-8 w-8 shrink-0" />
                <div className="hidden sm:flex items-center gap-2 flex-1 max-w-sm min-w-0 h-8 px-2.5 rounded-lg bg-muted/50">
                    <Search className="h-3.5 w-3.5 text-muted-foreground/40 shrink-0" />
                    <input type="text" placeholder="Buscar eleitores, demandas, eventos..." className="w-full bg-transparent text-[13px] text-foreground placeholder:text-muted-foreground/40 focus:outline-none min-w-0" />
                </div>
            </div>

            <div className="flex items-center gap-1 shrink-0">
                <ThemeToggle />

                {/* Notificações */}
                <div className="relative">
                    <button onClick={() => { setShowNotif(!showNotif); setShowUser(false) }}
                        className="relative h-8 w-8 flex items-center justify-center rounded-full hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
                        <Bell className="h-4 w-4" />
                        {unread > 0 && <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-destructive animate-dot-pulse" />}
                    </button>

                    {showNotif && (
                        <>
                            <div className="fixed inset-0 z-40" onClick={() => setShowNotif(false)} />
                            <div className="absolute top-full right-0 mt-2 w-[340px] bg-card rounded-2xl border shadow-2xl animate-scale-in z-50 overflow-hidden">
                                <div className="flex items-center justify-between px-4 py-3 border-b">
                                    <span className="text-[14px] font-semibold">Notificações</span>
                                    <div className="flex items-center gap-2">
                                        {unread > 0 && <button onClick={markAllRead} className="text-[11px] text-chart-1 hover:underline">Marcar todas</button>}
                                        <button onClick={() => setShowNotif(false)} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
                                    </div>
                                </div>
                                <div className="max-h-72 overflow-y-auto">
                                    {notificacoes.map((n) => {
                                        const isRead = n.lida || readIds.includes(n.id)
                                        return (
                                            <div key={n.id} onClick={() => markRead(n.id)}
                                                className={`px-4 py-3 border-b last:border-0 hover:bg-muted/50 transition-colors cursor-pointer ${!isRead ? "bg-chart-1/5" : ""}`}>
                                                <p className={`text-[13px] leading-snug ${!isRead ? "font-medium" : "text-muted-foreground"}`}>{n.mensagem}</p>
                                                <p className="text-[11px] text-muted-foreground/60 mt-1">{n.tempo}</p>
                                            </div>
                                        )
                                    })}
                                </div>
                            </div>
                        </>
                    )}
                </div>

                {/* Perfil */}
                <div className="relative">
                    <button onClick={() => { setShowUser(!showUser); setShowNotif(false) }}
                        className="flex items-center gap-1.5 h-8 pl-0.5 pr-2 rounded-full hover:bg-muted transition-colors ml-0.5 group">
                        <div className="h-7 w-7 rounded-full bg-gradient-to-br from-chart-1 to-chart-2 flex items-center justify-center text-[11px] font-bold text-white shrink-0">
                            CR
                        </div>
                        <ChevronDown className="h-3 w-3 text-muted-foreground group-hover:text-foreground transition-colors hidden sm:block" />
                    </button>

                    {showUser && (
                        <>
                            <div className="fixed inset-0 z-40" onClick={() => setShowUser(false)} />
                            <div className="absolute top-full right-0 mt-2 w-[240px] bg-card rounded-2xl border shadow-2xl animate-scale-in z-50 overflow-hidden">
                                <div className="p-4 border-b">
                                    <div className="flex items-center gap-3">
                                        <div className="h-10 w-10 rounded-full bg-gradient-to-br from-chart-1 to-chart-2 flex items-center justify-center text-[13px] font-bold text-white shrink-0">
                                            CR
                                        </div>
                                        <div className="min-w-0">
                                            <p className="text-[14px] font-semibold truncate">Cauã Rego</p>
                                            <p className="text-[11px] text-muted-foreground truncate">PSB · Vereador</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="py-1">
                                    <Link href="/configuracoes" onClick={() => setShowUser(false)}
                                        className="flex items-center gap-2.5 px-4 py-2.5 text-[13px] text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
                                        <User className="h-4 w-4" /> Meu Perfil
                                    </Link>
                                    <Link href="/configuracoes" onClick={() => setShowUser(false)}
                                        className="flex items-center gap-2.5 px-4 py-2.5 text-[13px] text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
                                        <Settings className="h-4 w-4" /> Configurações
                                    </Link>
                                    <button onClick={logout}
                                        className="flex items-center gap-2.5 px-4 py-2.5 text-[13px] text-destructive/70 hover:text-destructive hover:bg-muted transition-colors w-full">
                                        <LogOut className="h-4 w-4" /> Sair
                                    </button>
                                </div>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </header>
    )
}
