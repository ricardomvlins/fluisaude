"use client"

import { useState } from "react"
import { eleitores } from "@/lib/mock-data"
import { X, Save, MapPin, Phone, Mail, User, Briefcase, Heart, Users, Hash, Calendar, Globe, Home, CreditCard, MessageSquare } from "lucide-react"

type Field = { name: string; label: string; type: string; icon: React.ElementType; required?: boolean; placeholder?: string; options?: string[] }
type Section = { section: string; fields: Field[] }

const CAMPOS: Section[] = [
    {
        section: "Dados Pessoais", fields: [
            { name: "nome", label: "Nome Completo", type: "text", icon: User, required: true },
            { name: "cpf", label: "CPF", type: "text", icon: Hash, placeholder: "000.000.000-00" },
            { name: "dataNascimento", label: "Data de Nascimento", type: "date", icon: Calendar },
            { name: "genero", label: "Gênero", type: "select", icon: User, options: ["Masculino", "Feminino", "Outro", "Prefiro não dizer"] },
            { name: "estadoCivil", label: "Estado Civil", type: "select", icon: Heart, options: ["Solteiro(a)", "Casado(a)", "Divorciado(a)", "Viúvo(a)", "União Estável"] },
            { name: "escolaridade", label: "Escolaridade", type: "select", icon: Globe, options: ["Fundamental", "Médio", "Superior", "Pós-graduação", "Mestrado", "Doutorado"] },
        ]
    },
    {
        section: "Contato", fields: [
            { name: "telefone", label: "Telefone / WhatsApp", type: "tel", icon: Phone, required: true, placeholder: "(81) 99999-9999" },
            { name: "email", label: "E-mail", type: "email", icon: Mail },
            { name: "instagram", label: "Instagram", type: "text", icon: Globe, placeholder: "@usuario" },
            { name: "canalPreferido", label: "Canal Preferido", type: "select", icon: MessageSquare, options: ["WhatsApp", "Telefone", "E-mail", "Presencial", "Instagram"] },
        ]
    },
    {
        section: "Localização", fields: [
            { name: "cep", label: "CEP", type: "text", icon: MapPin, placeholder: "50000-000" },
            { name: "endereco", label: "Endereço", type: "text", icon: Home },
            { name: "numero", label: "Número", type: "text", icon: Hash },
            { name: "complemento", label: "Complemento", type: "text", icon: Home },
            { name: "bairro", label: "Bairro", type: "text", icon: MapPin, required: true },
            { name: "cidade", label: "Cidade", type: "text", icon: MapPin },
            { name: "estado", label: "Estado", type: "text", icon: Globe },
            { name: "zonaEleitoral", label: "Zona Eleitoral", type: "text", icon: Hash },
            { name: "secaoEleitoral", label: "Seção Eleitoral", type: "text", icon: Hash },
        ]
    },
    {
        section: "Perfil Político", fields: [
            { name: "apoio", label: "Nível de Apoio", type: "select", icon: Heart, required: true, options: ["Alto", "Médio", "Baixo", "Indeciso", "Oposição"] },
            { name: "profissao", label: "Profissão", type: "text", icon: Briefcase },
            { name: "classeSocial", label: "Classe Social Estimada", type: "select", icon: CreditCard, options: ["A", "B", "C", "D", "E"] },
            { name: "religiao", label: "Religião", type: "select", icon: Globe, options: ["Católica", "Evangélica", "Espírita", "Afro-brasileira", "Sem religião", "Outra"] },
            { name: "segmento", label: "Segmento", type: "select", icon: Users, options: ["Saúde", "Educação", "Comércio", "Igreja", "Comunidade", "Transporte", "Servidor Público", "Segurança", "Outro"] },
            { name: "lideranca", label: "Liderança Referência", type: "text", icon: Users },
            { name: "origemCadastro", label: "Origem do Cadastro", type: "select", icon: Globe, options: ["Porta a porta", "Evento", "Indicação", "Redes sociais", "WhatsApp", "Gabinete", "Outro"] },
        ]
    },
    {
        section: "Informações Adicionais", fields: [
            { name: "demandaPrincipal", label: "Demanda Principal", type: "textarea", icon: MessageSquare, placeholder: "Qual a principal necessidade desta pessoa?" },
            { name: "observacoes", label: "Observações", type: "textarea", icon: MessageSquare, placeholder: "Notas internas sobre o eleitor..." },
            { name: "tags", label: "Tags (separar por vírgula)", type: "text", icon: Hash, placeholder: "saúde, bairro x, líder" },
            { name: "consentimento", label: "Consentimento LGPD", type: "select", icon: Globe, options: ["Sim, autoriza uso dos dados", "Não autorizado", "Pendente"] },
        ]
    },
]

interface CadastroModalProps {
    open: boolean
    onClose: () => void
}

export function CadastroEleitorModal({ open, onClose }: CadastroModalProps) {
    const [form, setForm] = useState<Record<string, string>>({})
    const [saving, setSaving] = useState(false)

    if (!open) return null

    const update = (name: string, value: string) => setForm(p => ({ ...p, [name]: value }))

    const save = () => {
        setSaving(true)
        setTimeout(() => { setSaving(false); onClose(); setForm({}) }, 1000)
    }

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in" onClick={onClose}>
            <div className="w-full max-w-[720px] max-h-[90vh] bg-card rounded-2xl border shadow-2xl overflow-hidden animate-appear" onClick={e => e.stopPropagation()}>
                <div className="flex items-center justify-between px-6 py-4 border-b">
                    <div>
                        <h2 className="text-[18px] font-bold">Novo Eleitor</h2>
                        <p className="text-[12px] text-muted-foreground mt-0.5">Preencha o máximo de informações possível</p>
                    </div>
                    <button onClick={onClose} className="h-8 w-8 flex items-center justify-center rounded-full hover:bg-muted transition-colors text-muted-foreground"><X className="h-4 w-4" /></button>
                </div>

                <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6 space-y-6">
                    {CAMPOS.map(section => (
                        <div key={section.section}>
                            <h3 className="text-[12px] font-semibold text-muted-foreground uppercase tracking-wider mb-3">{section.section}</h3>
                            <div className="grid grid-cols-2 gap-3">
                                {section.fields.map(f => (
                                    <div key={f.name} className={f.type === "textarea" ? "col-span-2" : ""}>
                                        <label className="text-[12px] text-muted-foreground font-medium flex items-center gap-1.5 mb-1">
                                            <f.icon className="h-3 w-3" /> {f.label} {f.required && <span className="text-destructive">*</span>}
                                        </label>
                                        {f.type === "select" ? (
                                            <select value={form[f.name] || ""} onChange={e => update(f.name, e.target.value)}
                                                className="w-full h-9 px-3 rounded-xl bg-muted border border-border text-[13px] focus:outline-none focus:ring-1 focus:ring-chart-1/30 transition-all">
                                                <option value="">Selecionar...</option>
                                                {f.options?.map(o => <option key={o} value={o}>{o}</option>)}
                                            </select>
                                        ) : f.type === "textarea" ? (
                                            <textarea value={form[f.name] || ""} onChange={e => update(f.name, e.target.value)} placeholder={f.placeholder}
                                                className="w-full h-20 px-3 py-2 rounded-xl bg-muted border border-border text-[13px] focus:outline-none focus:ring-1 focus:ring-chart-1/30 transition-all resize-none" />
                                        ) : (
                                            <input type={f.type} value={form[f.name] || ""} onChange={e => update(f.name, e.target.value)} placeholder={f.placeholder}
                                                className="w-full h-9 px-3 rounded-xl bg-muted border border-border text-[13px] focus:outline-none focus:ring-1 focus:ring-chart-1/30 transition-all" />
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>

                <div className="flex items-center justify-end gap-2 px-6 py-4 border-t">
                    <button onClick={onClose} className="pill pill-outline h-9 px-5">Cancelar</button>
                    <button onClick={save} disabled={saving} className="pill pill-filled h-9 px-5 gap-1.5">
                        {saving ? <span className="flex gap-1">{[0, 100, 200].map(d => <span key={d} className="h-1.5 w-1.5 rounded-full bg-background/50 animate-bounce" style={{ animationDelay: `${d}ms` }} />)}</span> : <><Save className="h-3.5 w-3.5" /> Salvar Eleitor</>}
                    </button>
                </div>
            </div>
        </div>
    )
}
