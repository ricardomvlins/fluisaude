"use client"

import { usePathname } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import {
    Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent,
    SidebarGroupLabel, SidebarHeader, SidebarMenu, SidebarMenuButton,
    SidebarMenuItem, SidebarFooter,
} from "@/components/ui/sidebar"
import {
    LayoutDashboard, Users, MessageSquare, Calendar, Target,
    BarChart3, Map, Lightbulb, Bot, Megaphone,
    Settings, Activity, ChevronRight
} from "lucide-react"

const nav = [
    {
        section: "Principal", items: [
            { title: "Dashboard", url: "/", icon: LayoutDashboard },
            { title: "CRM Eleitoral", url: "/crm", icon: Users },
            { title: "Mapa Eleitoral", url: "/mapa", icon: Map },
        ]
    },
    {
        section: "Operação", items: [
            { title: "Atendimentos", url: "/atendimentos", icon: MessageSquare },
            { title: "Demandas", url: "/demandas", icon: Target },
            { title: "Agenda", url: "/agenda", icon: Calendar },
            { title: "Comunicação", url: "/comunicacao", icon: Megaphone },
        ]
    },
    {
        section: "Inteligência", items: [
            { title: "IA Política", url: "/ia", icon: Bot },
            { title: "Estratégia", url: "/estrategia", icon: Lightbulb },
            { title: "Relatórios", url: "/relatorios", icon: Activity },
            { title: "Pesquisas", url: "/pesquisas", icon: BarChart3 },
        ]
    },
    {
        section: "Sistema", items: [
            { title: "Configurações", url: "/configuracoes", icon: Settings },
        ]
    },
]

export function AppSidebar() {
    const pathname = usePathname()

    return (
        <Sidebar variant="sidebar" collapsible="offcanvas" className="border-r-0">
            <SidebarHeader className="h-14 flex items-center px-3 border-b border-sidebar-border overflow-hidden">
                <div className="flex items-center gap-2.5 overflow-hidden w-full">
                    <Image src="/alepe-logo.png" alt="ALEPE" width={28} height={28} className="rounded-lg shrink-0" />
                    <div className="overflow-hidden transition-all duration-300 group-data-[collapsible=icon]:w-0 group-data-[collapsible=icon]:opacity-0">
                        <p className="text-[13px] font-bold tracking-tight text-foreground leading-none whitespace-nowrap">ALEPE Política</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5 whitespace-nowrap">Gestão Política Inteligente</p>
                    </div>
                </div>
            </SidebarHeader>

            <SidebarContent className="px-2 pt-2 gap-0 overflow-x-hidden">
                {nav.map((group) => (
                    <SidebarGroup key={group.section} className="py-1">
                        <SidebarGroupLabel className="text-[10px] text-muted-foreground/40 uppercase tracking-[0.12em] font-semibold px-2 mb-0.5">
                            {group.section}
                        </SidebarGroupLabel>
                        <SidebarGroupContent>
                            <SidebarMenu>
                                {group.items.map((item) => {
                                    const active = pathname === item.url || (item.url !== "/" && pathname.startsWith(item.url))
                                    return (
                                        <SidebarMenuItem key={item.title}>
                                            <SidebarMenuButton
                                                tooltip={item.title}
                                                isActive={active}
                                                className={`
                          rounded-lg h-9 transition-all duration-200
                          ${active
                                                        ? "bg-sidebar-accent text-foreground font-medium"
                                                        : "text-muted-foreground hover:text-foreground hover:bg-sidebar-accent/50"
                                                    }
                        `}
                                                render={<Link href={item.url} />}
                                            >
                                                <item.icon className="size-[16px] shrink-0" />
                                                <span className="text-[13px] truncate">{item.title}</span>
                                                {active && <ChevronRight className="ml-auto size-3 opacity-30 group-data-[collapsible=icon]:hidden" />}
                                            </SidebarMenuButton>
                                        </SidebarMenuItem>
                                    )
                                })}
                            </SidebarMenu>
                        </SidebarGroupContent>
                    </SidebarGroup>
                ))}
            </SidebarContent>

            <SidebarFooter className="border-t border-sidebar-border px-3 py-3 overflow-hidden">
                <p className="text-[10px] text-muted-foreground/50 tracking-wider leading-relaxed whitespace-nowrap transition-all duration-300 group-data-[collapsible=icon]:opacity-0 group-data-[collapsible=icon]:w-0 group-data-[collapsible=icon]:overflow-hidden">
                    powered by <span className="font-semibold text-muted-foreground/70">operah</span> & <span className="font-semibold text-muted-foreground/70">alepe</span>
                </p>
            </SidebarFooter>
        </Sidebar>
    )
}
