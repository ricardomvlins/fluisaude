"use client"

import { createContext, useContext, useState, useCallback } from "react"
import { CheckCircle2, AlertTriangle, Info, X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

type ToastType = "success" | "warning" | "info"
interface Toast { id: string; message: string; type: ToastType }

const Ctx = createContext<{ toast: (msg: string, type?: ToastType) => void }>({ toast: () => { } })

export function useToast() { return useContext(Ctx) }

export function ToastContainer({ children }: { children: React.ReactNode }) {
    const [toasts, setToasts] = useState<Toast[]>([])

    const toast = useCallback((message: string, type: ToastType = "success") => {
        const id = Date.now().toString()
        setToasts(p => [...p, { id, message, type }])
        setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3000)
    }, [])

    const icons = { success: CheckCircle2, warning: AlertTriangle, info: Info }
    const colors = { success: "text-[#30d158]", warning: "text-[#ff9f0a]", info: "text-chart-1" }

    return (
        <Ctx.Provider value={{ toast }}>
            {children}
            <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2 pointer-events-none">
                <AnimatePresence mode="popLayout">
                    {toasts.map(t => {
                        const Icon = icons[t.type]
                        return (
                            <motion.div key={t.id}
                                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                                animate={{ opacity: 1, y: 0, scale: 1 }}
                                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                                transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                                className="pointer-events-auto flex items-center gap-2.5 px-4 py-3 bg-card border rounded-xl shadow-2xl min-w-[260px] max-w-[360px]"
                            >
                                <Icon className={`h-4 w-4 shrink-0 ${colors[t.type]}`} />
                                <p className="text-[13px] font-medium flex-1">{t.message}</p>
                                <button onClick={() => setToasts(p => p.filter(x => x.id !== t.id))} className="text-muted-foreground/40 hover:text-foreground shrink-0">
                                    <X className="h-3.5 w-3.5" />
                                </button>
                            </motion.div>
                        )
                    })}
                </AnimatePresence>
            </div>
        </Ctx.Provider>
    )
}
