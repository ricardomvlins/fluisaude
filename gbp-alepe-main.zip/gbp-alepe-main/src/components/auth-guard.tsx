"use client"

import { useEffect, useState } from "react"
import { usePathname, useRouter } from "next/navigation"

export function AuthGuard({ children }: { children: React.ReactNode }) {
    const pathname = usePathname()
    const router = useRouter()
    const [ok, setOk] = useState(false)

    useEffect(() => {
        if (pathname === "/login") { setOk(true); return }
        const auth = localStorage.getItem("gbp_auth")
        if (!auth) { router.replace("/login"); return }
        setOk(true)
    }, [pathname, router])

    if (!ok) return (
        <div className="h-screen flex items-center justify-center bg-background">
            <div className="flex gap-1.5">
                {[0, 150, 300].map(d => <span key={d} className="h-2 w-2 rounded-full bg-muted-foreground/30 animate-bounce" style={{ animationDelay: `${d}ms` }} />)}
            </div>
        </div>
    )

    return <>{children}</>
}
