"use client"

import { usePathname } from "next/navigation"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/app-sidebar"
import { TopHeader } from "@/components/top-header"
import { TooltipProvider } from "@/components/ui/tooltip"
import { AuthGuard } from "@/components/auth-guard"
import { ToastContainer } from "@/components/toast"

export function AppShell({ children }: { children: React.ReactNode }) {
    const pathname = usePathname()

    if (pathname === "/login") {
        return <AuthGuard>{children}</AuthGuard>
    }

    return (
        <AuthGuard>
            <ToastContainer>
                <TooltipProvider>
                    <SidebarProvider className="h-full">
                        <AppSidebar />
                        <SidebarInset className="flex flex-col h-full overflow-hidden">
                            <TopHeader />
                            <main className="flex-1 overflow-y-auto overflow-x-hidden">
                                {children}
                            </main>
                        </SidebarInset>
                    </SidebarProvider>
                </TooltipProvider>
            </ToastContainer>
        </AuthGuard>
    )
}
