// ===========================================================================
// GBP Político — Dados Mockados Centralizados
// ===========================================================================

// ----- ELEITORES -----
export interface Eleitor {
    id: string;
    nome: string;
    bairro: string;
    cidade: string;
    telefone: string;
    email: string;
    apoio: "Alto" | "Médio" | "Baixo" | "Indeciso";
    segmento: string;
    ultimaInteracao: string;
    score: number;
    tags: string[];
    genero: "M" | "F";
    idade: number;
    lideranca: string;
    status: "Ativo" | "Inativo" | "Novo";
}

export const eleitores: Eleitor[] = [
    { id: "1", nome: "Carlos Eduardo Silva", bairro: "Boa Viagem", cidade: "Recife", telefone: "(81) 99123-4567", email: "carlos@email.com", apoio: "Alto", segmento: "Comerciantes", ultimaInteracao: "Há 2 dias", score: 92, tags: ["Liderança", "Saúde"], genero: "M", idade: 45, lideranca: "João Marcos", status: "Ativo" },
    { id: "2", nome: "Ana Beatriz Souza", bairro: "Casa Forte", cidade: "Recife", telefone: "(81) 98234-5678", email: "ana@email.com", apoio: "Alto", segmento: "Educação", ultimaInteracao: "Há 1 dia", score: 88, tags: ["Professora", "Cultura"], genero: "F", idade: 38, lideranca: "Maria Helena", status: "Ativo" },
    { id: "3", nome: "Roberto Ferreira Lima", bairro: "Várzea", cidade: "Recife", telefone: "(81) 97345-6789", email: "roberto@email.com", apoio: "Médio", segmento: "Saúde", ultimaInteracao: "Há 1 semana", score: 65, tags: ["Médico", "SUS"], genero: "M", idade: 52, lideranca: "Dr. Paulo", status: "Ativo" },
    { id: "4", nome: "Juliana Costa Mendes", bairro: "Ibura", cidade: "Recife", telefone: "(81) 96456-7890", email: "juliana@email.com", apoio: "Baixo", segmento: "Juventude", ultimaInteracao: "Há 2 semanas", score: 35, tags: ["Estudante"], genero: "F", idade: 22, lideranca: "Pedro Alves", status: "Novo" },
    { id: "5", nome: "Marcos Antônio Reis", bairro: "Pina", cidade: "Recife", telefone: "(81) 95567-8901", email: "marcos@email.com", apoio: "Alto", segmento: "Transporte", ultimaInteracao: "Hoje", score: 95, tags: ["Presidente Assoc.", "Mobilidade"], genero: "M", idade: 60, lideranca: "João Marcos", status: "Ativo" },
    { id: "6", nome: "Fernanda Oliveira", bairro: "Espinheiro", cidade: "Recife", telefone: "(81) 94678-9012", email: "fernanda@email.com", apoio: "Médio", segmento: "Advocacia", ultimaInteracao: "Há 3 dias", score: 72, tags: ["OAB", "Direitos"], genero: "F", idade: 41, lideranca: "Maria Helena", status: "Ativo" },
    { id: "7", nome: "Diego Santos Barbosa", bairro: "Afogados", cidade: "Recife", telefone: "(81) 93789-0123", email: "diego@email.com", apoio: "Indeciso", segmento: "Comércio", ultimaInteracao: "Há 1 mês", score: 28, tags: ["Feira Livre"], genero: "M", idade: 33, lideranca: "Pedro Alves", status: "Inativo" },
    { id: "8", nome: "Patrícia Almeida", bairro: "Tejipió", cidade: "Recife", telefone: "(81) 92890-1234", email: "patricia@email.com", apoio: "Alto", segmento: "Saúde", ultimaInteracao: "Hoje", score: 90, tags: ["Enfermeira", "UBS"], genero: "F", idade: 29, lideranca: "Dr. Paulo", status: "Ativo" },
    { id: "9", nome: "Thiago Monteiro", bairro: "Boa Vista", cidade: "Recife", telefone: "(81) 91901-2345", email: "thiago@email.com", apoio: "Médio", segmento: "Tecnologia", ultimaInteracao: "Há 5 dias", score: 55, tags: ["Startups", "Inovação"], genero: "M", idade: 27, lideranca: "João Marcos", status: "Ativo" },
    { id: "10", nome: "Camila Rodrigues", bairro: "Torre", cidade: "Recife", telefone: "(81) 90012-3456", email: "camila@email.com", apoio: "Baixo", segmento: "Cultura", ultimaInteracao: "Há 3 semanas", score: 40, tags: ["Artista", "Teatro"], genero: "F", idade: 35, lideranca: "Maria Helena", status: "Inativo" },
    { id: "11", nome: "Wellington Macedo", bairro: "Cordeiro", cidade: "Recife", telefone: "(81) 99111-2222", email: "wellington@email.com", apoio: "Alto", segmento: "Educação", ultimaInteracao: "Há 1 dia", score: 85, tags: ["Diretor Escolar"], genero: "M", idade: 48, lideranca: "Dr. Paulo", status: "Ativo" },
    { id: "12", nome: "Larissa Monteiro", bairro: "Imbiribeira", cidade: "Recife", telefone: "(81) 98222-3333", email: "larissa@email.com", apoio: "Indeciso", segmento: "Assistência Social", ultimaInteracao: "Há 2 meses", score: 20, tags: ["CRAS"], genero: "F", idade: 31, lideranca: "Pedro Alves", status: "Inativo" },
];

// ----- KPIs DO DASHBOARD -----
export const dashboardKPIs = {
    eleitoresAtivos: 125430,
    eleitoresNovos: 1247,
    crescimentoEleitores: 5.2,
    demandasAbertas: 432,
    demandasResolvidas: 1893,
    taxaResolucao: 81.4,
    atendimentosHoje: 47,
    atendimentosPendentes: 18,
    agendaHoje: 10,
    visitasProgramadas: 8,
    reunioesMarcadas: 2,
    mensagensEnviadas: 12450,
    taxaEntrega: 98.2,
    taxaResposta: 34.7,
    engajamento: 67.5,
    bairrosAtivos: 42,
    liderancasAtivas: 156,
    scoreGeral: 78,
};

// ----- DADOS DE GRÁFICOS -----
export const evolucaoMensal = [
    { mes: "Jan", eleitores: 108000, interacoes: 4200, apoio: 72 },
    { mes: "Fev", eleitores: 110500, interacoes: 4800, apoio: 73 },
    { mes: "Mar", eleitores: 112000, interacoes: 5100, apoio: 71 },
    { mes: "Abr", eleitores: 114200, interacoes: 5600, apoio: 74 },
    { mes: "Mai", eleitores: 116800, interacoes: 6200, apoio: 75 },
    { mes: "Jun", eleitores: 118500, interacoes: 6800, apoio: 76 },
    { mes: "Jul", eleitores: 120100, interacoes: 7100, apoio: 74 },
    { mes: "Ago", eleitores: 121900, interacoes: 7500, apoio: 77 },
    { mes: "Set", eleitores: 123400, interacoes: 7900, apoio: 78 },
    { mes: "Out", eleitores: 124800, interacoes: 8200, apoio: 76 },
    { mes: "Nov", eleitores: 125430, interacoes: 8600, apoio: 78 },
];

export const demandaPorCategoria = [
    { nome: "Saúde", valor: 156, cor: "#10b981" },
    { nome: "Infraestrutura", valor: 124, cor: "#f59e0b" },
    { nome: "Educação", valor: 89, cor: "#3b82f6" },
    { nome: "Segurança", valor: 67, cor: "#ef4444" },
    { nome: "Transporte", valor: 52, cor: "#8b5cf6" },
    { nome: "Assistência Social", valor: 38, cor: "#6366f1" },
];

export const apoioPorBairro = [
    { bairro: "Boa Viagem", apoio: 82, eleitores: 8420 },
    { bairro: "Casa Forte", apoio: 78, eleitores: 5230 },
    { bairro: "Espinheiro", apoio: 75, eleitores: 4100 },
    { bairro: "Pina", apoio: 71, eleitores: 3800 },
    { bairro: "Aflitos", apoio: 69, eleitores: 2900 },
    { bairro: "Várzea", apoio: 64, eleitores: 6700 },
    { bairro: "Ibura", apoio: 45, eleitores: 9200 },
    { bairro: "Afogados", apoio: 38, eleitores: 7100 },
];

// ----- ATENDIMENTOS -----
export interface Atendimento {
    id: string;
    protocolo: string;
    eleitor: string;
    categoria: string;
    canal: string;
    responsavel: string;
    status: "aberto" | "triagem" | "andamento" | "aguardando" | "concluido";
    prioridade: "alta" | "media" | "baixa";
    prazo: string;
    resumo: string;
    dataAbertura: string;
}

export const atendimentos: Atendimento[] = [
    { id: "1", protocolo: "ATD-2026-001", eleitor: "Carlos Eduardo Silva", categoria: "Saúde", canal: "WhatsApp", responsavel: "Ana Assessora", status: "andamento", prioridade: "alta", prazo: "12/03/2026", resumo: "Solicitação de vaga em UBS de Boa Viagem", dataAbertura: "08/03/2026" },
    { id: "2", protocolo: "ATD-2026-002", eleitor: "Ana Beatriz Souza", categoria: "Educação", canal: "Presencial", responsavel: "Carlos Coord.", status: "aberto", prioridade: "media", prazo: "15/03/2026", resumo: "Reforma da escola municipal no bairro Casa Forte", dataAbertura: "09/03/2026" },
    { id: "3", protocolo: "ATD-2026-003", eleitor: "Roberto Ferreira Lima", categoria: "Infraestrutura", canal: "Telefone", responsavel: "Ana Assessora", status: "triagem", prioridade: "alta", prazo: "11/03/2026", resumo: "Buraco na Rua da Várzea causando acidentes", dataAbertura: "07/03/2026" },
    { id: "4", protocolo: "ATD-2026-004", eleitor: "Marcos Antônio Reis", categoria: "Transporte", canal: "WhatsApp", responsavel: "Pedro Analista", status: "aguardando", prioridade: "media", prazo: "18/03/2026", resumo: "Nova linha de ônibus para atender Pina e adjacências", dataAbertura: "05/03/2026" },
    { id: "5", protocolo: "ATD-2026-005", eleitor: "Fernanda Oliveira", categoria: "Segurança", canal: "Email", responsavel: "Carlos Coord.", status: "concluido", prioridade: "baixa", prazo: "10/03/2026", resumo: "Iluminação pública na praça do Espinheiro restaurada", dataAbertura: "01/03/2026" },
    { id: "6", protocolo: "ATD-2026-006", eleitor: "Patrícia Almeida", categoria: "Saúde", canal: "Presencial", responsavel: "Ana Assessora", status: "andamento", prioridade: "alta", prazo: "13/03/2026", resumo: "Falta de medicamentos no posto do Tejipió", dataAbertura: "09/03/2026" },
    { id: "7", protocolo: "ATD-2026-007", eleitor: "Thiago Monteiro", categoria: "Tecnologia", canal: "WhatsApp", responsavel: "Pedro Analista", status: "aberto", prioridade: "baixa", prazo: "20/03/2026", resumo: "Projeto Wi-Fi público para praças da Boa Vista", dataAbertura: "10/03/2026" },
    { id: "8", protocolo: "ATD-2026-008", eleitor: "Juliana Costa Mendes", categoria: "Assistência Social", canal: "Telefone", responsavel: "Carlos Coord.", status: "triagem", prioridade: "alta", prazo: "12/03/2026", resumo: "Família precisa de cadastro emergencial no CadÚnico", dataAbertura: "10/03/2026" },
];

// ----- AGENDA -----
export interface Evento {
    id: string;
    titulo: string;
    tipo: "reuniao" | "visita" | "evento" | "ligacao" | "campanha" | "entrevista";
    data: string;
    hora: string;
    local: string;
    participantes: string[];
    status: "confirmado" | "pendente" | "cancelado";
}

export const agenda: Evento[] = [
    { id: "1", titulo: "Visita ao Posto de Saúde da Várzea", tipo: "visita", data: "2026-03-10", hora: "08:00", local: "UBS Várzea, Recife", participantes: ["João Marcos", "Dr. Paulo"], status: "confirmado" },
    { id: "2", titulo: "Reunião com lideranças de Afogados", tipo: "reuniao", data: "2026-03-10", hora: "10:30", local: "Centro Comunitário Afogados", participantes: ["Pedro Alves", "Maria Helena", "Diego Santos"], status: "confirmado" },
    { id: "3", titulo: "Evento de Inauguração - Praça Boa Viagem", tipo: "evento", data: "2026-03-10", hora: "14:00", local: "Praça de Boa Viagem", participantes: ["Equipe Completa"], status: "pendente" },
    { id: "4", titulo: "Ligação para lideranças do Ibura", tipo: "ligacao", data: "2026-03-10", hora: "16:00", local: "Gabinete", participantes: ["Ana Assessora"], status: "confirmado" },
    { id: "5", titulo: "Gravação de conteúdo - Campanha Saúde", tipo: "campanha", data: "2026-03-11", hora: "09:00", local: "Estúdio Central", participantes: ["Equipe Comunicação"], status: "pendente" },
    { id: "6", titulo: "Entrevista Rádio Jornal", tipo: "entrevista", data: "2026-03-11", hora: "11:00", local: "Rádio Jornal, Recife", participantes: ["Assessor de Imprensa"], status: "confirmado" },
    { id: "7", titulo: "Visita à Escola Municipal Torre", tipo: "visita", data: "2026-03-12", hora: "08:30", local: "Escola Mun. Torre", participantes: ["Carlos Coord.", "Wellington Macedo"], status: "pendente" },
    { id: "8", titulo: "Reunião de estratégia semanal", tipo: "reuniao", data: "2026-03-12", hora: "15:00", local: "Gabinete", participantes: ["Equipe Completa"], status: "confirmado" },
];

// ----- ATIVIDADES RECENTES -----
export interface Atividade {
    id: string;
    tipo: "eleitor" | "atendimento" | "demanda" | "campanha" | "ia";
    descricao: string;
    tempo: string;
    usuario: string;
}

export const atividadesRecentes: Atividade[] = [
    { id: "1", tipo: "eleitor", descricao: "Novo cadastro: Patrícia Almeida (Tejipió)", tempo: "Há 5 min", usuario: "Ana Assessora" },
    { id: "2", tipo: "atendimento", descricao: "Atendimento ATD-2026-005 concluído com sucesso", tempo: "Há 15 min", usuario: "Carlos Coord." },
    { id: "3", tipo: "demanda", descricao: "Nova demanda de infraestrutura registrada (Várzea)", tempo: "Há 30 min", usuario: "Pedro Analista" },
    { id: "4", tipo: "campanha", descricao: "Campanha 'Saúde para Todos' atingiu 12.4k envios", tempo: "Há 1 hora", usuario: "Equipe Comunicação" },
    { id: "5", tipo: "ia", descricao: "IA identificou oportunidade no bairro Cordeiro", tempo: "Há 2 horas", usuario: "Sistema IA" },
    { id: "6", tipo: "eleitor", descricao: "Score de Marcos Antônio Reis atualizado para 95", tempo: "Há 3 horas", usuario: "Sistema" },
    { id: "7", tipo: "atendimento", descricao: "Novo atendimento aberto via WhatsApp", tempo: "Há 4 horas", usuario: "Ana Assessora" },
];

// ----- INSIGHTS IA -----
export interface InsightIA {
    id: string;
    tipo: "alerta" | "oportunidade" | "sugestao" | "tendencia";
    titulo: string;
    descricao: string;
    bairro?: string;
    impacto: "alto" | "medio" | "baixo";
    acao?: string;
}

export const insightsIA: InsightIA[] = [
    { id: "1", tipo: "alerta", titulo: "Queda de apoio em Afogados", descricao: "O apoio estimado caiu 4% nas últimas 2 semanas. Foram registradas 12 novas demandas não atendidas na área de infraestrutura.", bairro: "Afogados", impacto: "alto", acao: "Agendar visita com liderança local e priorizar demandas pendentes" },
    { id: "2", tipo: "oportunidade", titulo: "Crescimento em Boa Viagem", descricao: "200 novos eleitores cadastrados este mês. O segmento de comerciantes mostra engajamento de 89%. Ótimo momento para ação de fidelização.", bairro: "Boa Viagem", impacto: "alto", acao: "Criar campanha de WhatsApp para comerciantes com resultados recentes" },
    { id: "3", tipo: "sugestao", titulo: "Campanha de Saúde no Tejipió", descricao: "Há 47 demandas ativas de saúde na região. Uma visita ao posto local com cobertura de mídia poderia fortalecer a presença territorial.", bairro: "Tejipió", impacto: "medio", acao: "Agendar visita com equipe de comunicação" },
    { id: "4", tipo: "tendencia", titulo: "Juventude engajando mais", descricao: "O segmento 18-25 anos aumentou interações em 23% após a última live. Considerar mais ações digitais para esse público.", impacto: "medio", acao: "Planejar 2 lives temáticas por mês" },
];

// ----- NOTIFICAÇÕES -----
export interface Notificacao {
    id: string;
    tipo: "tarefa" | "demanda" | "campanha" | "agenda" | "ia" | "sistema";
    mensagem: string;
    tempo: string;
    lida: boolean;
}

export const notificacoes: Notificacao[] = [
    { id: "1", tipo: "ia", mensagem: "IA identificou 3 bairros com queda de apoio esta semana", tempo: "Há 10 min", lida: false },
    { id: "2", tipo: "agenda", mensagem: "Reunião com lideranças de Afogados em 30 minutos", tempo: "Há 25 min", lida: false },
    { id: "3", tipo: "demanda", mensagem: "Demanda #432 de infraestrutura está perto do prazo", tempo: "Há 1 hora", lida: false },
    { id: "4", tipo: "campanha", mensagem: "Campanha 'Saúde para Todos' atingiu 98% de entrega", tempo: "Há 2 horas", lida: true },
    { id: "5", tipo: "tarefa", mensagem: "Retorno pendente para Roberto Ferreira Lima", tempo: "Há 3 horas", lida: true },
];
