export function construction(title: string, description: string, emoji: string) {
    return (
        <div className="p-6 lg:p-8 xl:p-10 max-w-[1440px] mx-auto page-enter">
            <div className="mb-8">
                <h1 className="text-[32px] font-bold tracking-tight">{title}</h1>
                <p className="text-[14px] text-muted-foreground mt-1">{description}</p>
            </div>
            <div className="bg-card rounded-2xl border flex flex-col items-center justify-center py-24">
                <span className="text-5xl mb-4 animate-float">{emoji}</span>
                <h2 className="text-[17px] font-semibold mb-1">Em Construção</h2>
                <p className="text-[13px] text-muted-foreground text-center max-w-sm leading-relaxed">
                    Este módulo estará disponível em breve.
                </p>
                <p className="text-[10px] text-muted-foreground/40 mt-6 tracking-wider">
                    powered by <span className="font-semibold text-muted-foreground/60">operah</span> & <span className="font-semibold text-muted-foreground/60">alepe</span>
                </p>
            </div>
        </div>
    )
}
