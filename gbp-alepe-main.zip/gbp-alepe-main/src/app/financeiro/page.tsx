import { construction } from "@/lib/module-pages"
export default function FinanceiroPage() { return construction("Financeiro Operacional", "Centros de custo, despesas operacionais e orçamento", "💰") }
