"use client"

import { demandaPorCategoria } from "@/lib/mock-data"
import { Target, MapPin, Clock, AlertTriangle, CheckCircle2, Plus, ArrowRight } from "lucide-react"
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from "recharts"
import { useToast } from "@/components/toast"

const demandas = [
    { id: "1", titulo: "Buraco na Rua da Várzea", cat: "Infraestrutura", bairro: "Várzea", urg: "Alta", dias: 3 },
    { id: "2", titulo: "Falta de medicamentos no posto", cat: "Saúde", bairro: "Tejipió", urg: "Alta", dias: 5 },
    { id: "3", titulo: "Iluminação pública precária", cat: "Segurança", bairro: "Ibura", urg: "Média", dias: 7 },
    { id: "4", titulo: "Reforma da escola municipal", cat: "Educação", bairro: "Casa Forte", urg: "Média", dias: 12 },
    { id: "5", titulo: "Nova linha de ônibus", cat: "Transporte", bairro: "Pina", urg: "Baixa", dias: 15 },
    { id: "6", titulo: "Programa social para jovens", cat: "Social", bairro: "Afogados", urg: "Média", dias: 2 },
]

const urgC: Record<string, string> = { Alta: "bg-[#ff453a]/15 text-[#ff453a]", Média: "bg-[#ff9f0a]/15 text-[#ff9f0a]", Baixa: "bg-[#8e8e93]/10 text-muted-foreground" }

export default function DemandasPage() {
    const { toast } = useToast()
    return (
        <div className="p-6 lg:p-8 xl:p-10 max-w-[1440px] mx-auto page-enter space-y-8">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-[32px] font-bold tracking-tight text-foreground">Demandas</h1>
                    <p className="text-[14px] text-muted-foreground mt-1">Controle de solicitações</p>
                </div>
                <button onClick={() => toast("Nova demanda criada com sucesso!")} className="pill pill-filled h-9 px-4 gap-1.5"><Plus className="h-3.5 w-3.5" /> Nova Demanda</button>
            </div>

            <div className="grid grid-cols-4 gap-3 stagger">
                {[
                    { l: "Total Abertas", v: "432", icon: Target, c: "text-[#5ac8fa]" },
                    { l: "Alta Urgência", v: "67", icon: AlertTriangle, c: "text-[#ff453a]" },
                    { l: "Resolvidas", v: "189", icon: CheckCircle2, c: "text-[#30d158]" },
                    { l: "Tempo Médio", v: "4.2d", icon: Clock, c: "text-[#ff9f0a]" },
                ].map(s => (
                    <div key={s.l} className="bg-card rounded-2xl p-4 border border-border hover:border-border transition-all flex items-center gap-3 cursor-pointer">
                        <s.icon className={`h-5 w-5 ${s.c}`} />
                        <div><p className="text-xl font-bold text-foreground">{s.v}</p><p className="text-[11px] text-muted-foreground/60">{s.l}</p></div>
                    </div>
                ))}
            </div>

            <div className="grid gap-4 lg:grid-cols-3">
                <div className="bg-card rounded-2xl p-6 border border-border animate-appear">
                    <h2 className="text-[15px] font-semibold text-foreground mb-4">Por Categoria</h2>
                    <ResponsiveContainer width="100%" height={220}>
                        <BarChart data={demandaPorCategoria} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                            <XAxis dataKey="nome" tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                            <YAxis tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                            <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: "12px", fontSize: "12px", color: "var(--foreground)" }} />
                            <Bar dataKey="valor" radius={[8, 8, 0, 0]} maxBarSize={28}>
                                {demandaPorCategoria.map((e, i) => <Cell key={i} fill={e.cor} />)}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>

                <div className="lg:col-span-2 bg-card rounded-2xl border border-border overflow-hidden animate-appear" style={{ animationDelay: "0.1s" }}>
                    <div className="px-5 py-4 border-b border-border"><h2 className="text-[15px] font-semibold text-foreground">Recentes</h2></div>
                    <div className="divide-y divide-border">
                        {demandas.map(d => (
                            <div key={d.id} onClick={() => toast(`Abrindo demanda: ${d.titulo}`, "info")} className="flex items-center gap-4 px-5 py-3.5 hover:bg-muted/30 transition-colors cursor-pointer group">
                                <div className="flex-1 min-w-0">
                                    <p className="text-[13px] font-medium text-foreground truncate">{d.titulo}</p>
                                    <div className="flex items-center gap-3 mt-1 text-[11px] text-muted-foreground/60">
                                        <span className="flex items-center gap-1"><MapPin className="h-2.5 w-2.5" />{d.bairro}</span>
                                        <span>{d.cat}</span>
                                        <span className="flex items-center gap-1"><Clock className="h-2.5 w-2.5" />{d.dias}d</span>
                                    </div>
                                </div>
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${urgC[d.urg]}`}>{d.urg}</span>
                                <ArrowRight className="h-3.5 w-3.5 text-muted-foreground/40 group-hover:text-foreground transition-colors" />
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    )
}
