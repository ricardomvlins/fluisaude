import { construction } from "@/lib/module-pages"
export default function DocumentosPage() { return construction("Documentos", "Central de arquivos e documentos operacionais", "📁") }
