"use client"

import { useState } from "react"
import { atendimentos, type Atendimento } from "@/lib/mock-data"
import { Clock, CheckCircle2, Inbox, ArrowRight, Phone, MessageSquare, Mail, User, Filter, Plus, Search } from "lucide-react"
import { useToast } from "@/components/toast"

const columns: { id: Atendimento["status"]; label: string; color: string; icon: React.ElementType }[] = [
    { id: "aberto", label: "Aberto", color: "bg-[#5ac8fa]", icon: Inbox },
    { id: "triagem", label: "Triagem", color: "bg-[#ff9f0a]", icon: Filter },
    { id: "andamento", label: "Em Andamento", color: "bg-[#af52de]", icon: ArrowRight },
    { id: "aguardando", label: "Aguardando", color: "bg-[#ff9f0a]", icon: Clock },
    { id: "concluido", label: "Concluído", color: "bg-[#30d158]", icon: CheckCircle2 },
]

const prioStyle: Record<string, string> = {
    alta: "bg-[#ff453a]/15 text-[#ff453a]",
    media: "bg-[#ff9f0a]/15 text-[#ff9f0a]",
    baixa: "bg-muted text-muted-foreground",
}

const canalIcon: Record<string, React.ReactNode> = {
    WhatsApp: <MessageSquare className="h-3 w-3 text-[#30d158]" />,
    Telefone: <Phone className="h-3 w-3 text-[#5ac8fa]" />,
    Email: <Mail className="h-3 w-3 text-muted-foreground" />,
    Presencial: <User className="h-3 w-3 text-[#af52de]" />,
}

export default function AtendimentosPage() {
    const [items, setItems] = useState(atendimentos)
    const [dragging, setDragging] = useState<string | null>(null)
    const [over, setOver] = useState<string | null>(null)
    const [search, setSearch] = useState("")
    const { toast } = useToast()

    const drop = (colId: Atendimento["status"]) => {
        if (!dragging) return
        const item = items.find(x => x.id === dragging)
        if (item && item.status !== colId) {
            setItems(p => p.map(x => x.id === dragging ? { ...x, status: colId } : x))
            const col = columns.find(c => c.id === colId)
            toast(`Movido para ${col?.label}`)
        }
        setDragging(null)
        setOver(null)
    }

    const filtered = search
        ? items.filter(a => a.resumo.toLowerCase().includes(search.toLowerCase()) || a.eleitor.toLowerCase().includes(search.toLowerCase()))
        : items

    const totais = {
        pendentes: items.filter(a => a.status !== "concluido").length,
        urgentes: items.filter(a => a.prioridade === "alta").length,
        concluidos: items.filter(a => a.status === "concluido").length,
    }

    return (
        <div className="flex flex-col h-full">
            {/* Fixed header */}
            <div className="shrink-0 px-6 lg:px-8 pt-6 lg:pt-8 pb-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                    <div>
                        <h1 className="text-[28px] lg:text-[32px] font-bold tracking-tight">Atendimentos</h1>
                        <p className="text-[13px] text-muted-foreground mt-0.5">Gerencie solicitações • Arraste cards entre colunas</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                        <div className="flex items-center gap-2 h-9 px-3 rounded-xl border bg-card">
                            <Search className="h-3.5 w-3.5 text-muted-foreground/40 shrink-0" />
                            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar..."
                                className="bg-transparent text-[13px] placeholder:text-muted-foreground/40 focus:outline-none w-28 sm:w-36" />
                        </div>
                        <button onClick={() => toast("Novo atendimento criado!")} className="pill pill-filled h-9 px-4 gap-1.5 shrink-0">
                            <Plus className="h-3.5 w-3.5" /> Novo
                        </button>
                    </div>
                </div>

                <div className="flex gap-2">
                    {[
                        { l: `${totais.pendentes} pendentes`, c: "text-[#5ac8fa]", bg: "bg-[#5ac8fa]" },
                        { l: `${totais.urgentes} urgentes`, c: "text-[#ff453a]", bg: "bg-[#ff453a]" },
                        { l: `${totais.concluidos} concluídos`, c: "text-[#30d158]", bg: "bg-[#30d158]" },
                    ].map(s => (
                        <span key={s.l} className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[12px] font-medium ${s.c}`}>
                            <span className={`h-1.5 w-1.5 rounded-full ${s.bg}`} />{s.l}
                        </span>
                    ))}
                </div>
            </div>

            {/* Kanban — fills remaining height, scrolls horizontally */}
            <div className="flex-1 min-h-0 overflow-x-auto overflow-y-hidden px-6 lg:px-8 pb-4">
                <div className="flex gap-3 h-full" style={{ minWidth: `${columns.length * 264}px` }}>
                    {columns.map(col => {
                        const ci = filtered.filter(a => a.status === col.id)
                        const isOver = over === col.id && dragging
                        return (
                            <div key={col.id}
                                className={`flex flex-col flex-1 min-w-[240px] rounded-2xl border transition-colors duration-150 ${isOver ? "bg-muted/60 border-foreground/15" : "bg-card"
                                    }`}
                                onDragOver={e => { e.preventDefault(); setOver(col.id) }}
                                onDragLeave={() => setOver(null)}
                                onDrop={() => drop(col.id)}>

                                <div className="flex items-center gap-2 px-3.5 py-3 border-b shrink-0">
                                    <span className={`h-2 w-2 rounded-full ${col.color} shrink-0`} />
                                    <span className="text-[13px] font-semibold flex-1">{col.label}</span>
                                    <span className="text-[11px] font-medium text-muted-foreground bg-muted rounded-full h-5 min-w-5 flex items-center justify-center px-1.5">
                                        {ci.length}
                                    </span>
                                </div>

                                <div className="flex flex-col gap-2 p-2 flex-1 overflow-y-auto min-h-0">
                                    {ci.map(a => (
                                        <div key={a.id} draggable
                                            onDragStart={() => setDragging(a.id)}
                                            onDragEnd={() => { setDragging(null); setOver(null) }}
                                            className={`p-3 rounded-xl border cursor-grab active:cursor-grabbing transition-all duration-150 ${dragging === a.id ? "opacity-30 scale-[0.97]" : "bg-background hover:border-foreground/10 hover:shadow-sm"
                                                }`}>
                                            <div className="flex items-center justify-between mb-2">
                                                <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-semibold ${prioStyle[a.prioridade]}`}>
                                                    {a.prioridade === "alta" ? "Alta" : a.prioridade === "media" ? "Média" : "Baixa"}
                                                </span>
                                                <span className="text-[10px] text-muted-foreground/40 font-mono">{a.protocolo}</span>
                                            </div>
                                            <p className="text-[13px] font-medium leading-snug mb-2 line-clamp-2">{a.resumo}</p>
                                            <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                                                <span className="flex items-center gap-1 truncate">{canalIcon[a.canal]}{a.eleitor.split(" ").slice(0, 2).join(" ")}</span>
                                                <span className="flex items-center gap-1 shrink-0"><Clock className="h-2.5 w-2.5" />{a.prazo}</span>
                                            </div>
                                            <div className="flex items-center gap-1.5 mt-2 pt-2 border-t">
                                                <div className="h-5 w-5 rounded-full bg-gradient-to-br from-chart-1/20 to-chart-2/20 flex items-center justify-center text-[8px] font-bold shrink-0">
                                                    {a.responsavel.split(" ").map(n => n[0]).slice(0, 2).join("")}
                                                </div>
                                                <span className="text-[11px] text-muted-foreground/60 truncate">{a.responsavel}</span>
                                            </div>
                                        </div>
                                    ))}
                                    {ci.length === 0 && (
                                        <div className="flex flex-col items-center justify-center py-8 text-muted-foreground/30">
                                            <col.icon className="h-5 w-5 mb-1.5" /><span className="text-[11px]">Nenhum item</span>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
        </div>
    )
}
