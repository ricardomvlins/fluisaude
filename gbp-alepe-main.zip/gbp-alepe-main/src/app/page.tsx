"use client"

import { motion } from "framer-motion"
import {
  Users, AlertCircle, Calendar, Send, Sparkles, TrendingUp,
  TrendingDown, ArrowUpRight, Target, MessageSquare, Bot,
  Clock, Activity
} from "lucide-react"
import {
  dashboardKPIs, evolucaoMensal, demandaPorCategoria,
  apoioPorBairro, atividadesRecentes, insightsIA
} from "@/lib/mock-data"
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell
} from "recharts"

const fadeUp = { hidden: { opacity: 0, y: 16 }, show: { opacity: 1, y: 0 } }
const stagger = { show: { transition: { staggerChildren: 0.06 } } }

function Kpi({ title, value, change, changeType, icon: Icon, suffix, i }: {
  title: string; value: string | number; change: string; changeType: "up" | "down" | "neutral";
  icon: React.ElementType; suffix?: string; i: number;
}) {
  return (
    <motion.div
      variants={fadeUp}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className="bg-card rounded-2xl p-5 border hover:border-foreground/10 transition-all duration-300 cursor-pointer group"
    >
      <div className="flex items-center justify-between mb-4">
        <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-[0.1em]">{title}</span>
        <div className="h-8 w-8 rounded-xl bg-muted flex items-center justify-center group-hover:bg-accent transition-colors">
          <Icon className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
        </div>
      </div>
      <p className="text-[28px] lg:text-[32px] font-bold tracking-tight leading-none">
        {typeof value === "number" ? value.toLocaleString("pt-BR") : value}
        {suffix && <span className="text-[13px] font-normal text-muted-foreground ml-1.5">{suffix}</span>}
      </p>
      <p className={`text-[12px] font-medium mt-2.5 flex items-center gap-1 ${changeType === "up" ? "text-[#30d158]" : changeType === "down" ? "text-[#ff453a]" : "text-muted-foreground"
        }`}>
        {changeType === "up" && <TrendingUp className="h-3 w-3" />}
        {changeType === "down" && <TrendingDown className="h-3 w-3" />}
        {change}
      </p>
    </motion.div>
  )
}

export default function DashboardPage() {
  const today = new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })
  const greeting = new Date().getHours() < 12 ? "Bom dia" : new Date().getHours() < 18 ? "Boa tarde" : "Boa noite"

  return (
    <div className="p-6 lg:p-8 xl:p-10">
      <div className="max-w-[1440px] mx-auto space-y-6">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}>
          <p className="text-[13px] text-muted-foreground font-medium">{greeting} 👋</p>
          <h1 className="text-[28px] lg:text-[36px] font-bold tracking-tight mt-0.5">Dashboard</h1>
          <p className="text-[13px] text-muted-foreground/60 mt-1 capitalize">{today}</p>
        </motion.div>

        {/* KPIs */}
        <motion.div variants={stagger} initial="hidden" animate="show" className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
          <Kpi i={0} title="Eleitores" value={dashboardKPIs.eleitoresAtivos} change={`+${dashboardKPIs.crescimentoEleitores}% este mês`} changeType="up" icon={Users} />
          <Kpi i={1} title="Demandas" value={dashboardKPIs.demandasAbertas} change={`${dashboardKPIs.taxaResolucao}% resolvidas`} changeType="up" icon={AlertCircle} />
          <Kpi i={2} title="Agenda" value={dashboardKPIs.agendaHoje} change={`${dashboardKPIs.visitasProgramadas} visitas`} changeType="neutral" icon={Calendar} suffix="eventos" />
          <Kpi i={3} title="Engajamento" value={`${dashboardKPIs.taxaEntrega}%`} change={`${dashboardKPIs.mensagensEnviadas.toLocaleString("pt-BR")} enviadas`} changeType="up" icon={Send} />
        </motion.div>

        {/* Charts row */}
        <div className="grid gap-4 grid-cols-1 lg:grid-cols-5">
          {/* Area Chart */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-3 bg-card rounded-2xl p-5 lg:p-6 border min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-5">
              <div>
                <h2 className="text-[15px] lg:text-[17px] font-semibold">Evolução da Base</h2>
                <p className="text-[11px] text-muted-foreground/60 mt-0.5">Últimos 6 meses</p>
              </div>
              <div className="flex gap-4 text-[11px] text-muted-foreground">
                <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-chart-1" /> Eleitores</span>
                <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-chart-3" /> Apoio</span>
              </div>
            </div>
            <div className="w-full" style={{ minHeight: 0 }}>
              <ResponsiveContainer width="100%" height={240}>
                <AreaChart data={evolucaoMensal} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                  <defs>
                    <linearGradient id="ge" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.15} />
                      <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="ga" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--chart-3)" stopOpacity={0.1} />
                      <stop offset="100%" stopColor="var(--chart-3)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="mes" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <YAxis yAxisId="left" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} domain={[60, 100]} />
                  <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: "12px", fontSize: "12px", color: "var(--foreground)" }}
                    formatter={(value: any, name: any) => [name === "eleitores" ? Number(value).toLocaleString("pt-BR") : `${value}%`, name === "eleitores" ? "Eleitores" : "Apoio"]} />
                  <Area yAxisId="left" type="monotone" dataKey="eleitores" stroke="var(--chart-1)" strokeWidth={2} fill="url(#ge)" dot={false} activeDot={{ r: 4, strokeWidth: 0 }} />
                  <Area yAxisId="right" type="monotone" dataKey="apoio" stroke="var(--chart-3)" strokeWidth={1.5} fill="url(#ga)" dot={false} strokeDasharray="4 4" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* IA Insights */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-2 bg-card rounded-2xl border overflow-hidden min-w-0 flex flex-col">
            <div className="px-5 py-4 border-b flex items-center gap-3 shrink-0">
              <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-chart-2 to-chart-5 flex items-center justify-center shadow-lg shadow-chart-2/10">
                <Sparkles className="h-4 w-4 text-white" />
              </div>
              <div>
                <span className="text-[14px] font-semibold">Operah IA</span>
                <span className="flex items-center gap-1.5 mt-0.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#30d158] animate-dot-pulse" />
                  <span className="text-[11px] text-muted-foreground/60">Ativo</span>
                </span>
              </div>
            </div>
            <div className="p-3 flex-1 overflow-y-auto space-y-1">
              {insightsIA.slice(0, 4).map((ins, i) => (
                <motion.div key={ins.id} initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 + i * 0.08, duration: 0.3 }}
                  className="p-3 rounded-xl border border-transparent hover:border-border hover:bg-muted/50 transition-all cursor-pointer group">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`h-1.5 w-1.5 rounded-full shrink-0 ${ins.tipo === "alerta" ? "bg-destructive" : ins.tipo === "oportunidade" ? "bg-[#30d158]" : "bg-chart-1"
                      }`} />
                    <span className="text-[13px] font-medium leading-none">{ins.titulo}</span>
                  </div>
                  <p className="text-[12px] text-muted-foreground leading-relaxed ml-3.5 line-clamp-2">{ins.descricao}</p>
                  {ins.acao && (
                    <p className="text-[11px] font-medium text-chart-2 opacity-0 group-hover:opacity-100 transition-opacity mt-1.5 ml-3.5 flex items-center gap-0.5">
                      <ArrowUpRight className="h-3 w-3" /> {ins.acao}
                    </p>
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Bottom row */}
        <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {/* Pie */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="bg-card rounded-2xl p-5 lg:p-6 border min-w-0">
            <h2 className="text-[15px] font-semibold mb-4">Demandas por Categoria</h2>
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie data={demandaPorCategoria} cx="50%" cy="50%" innerRadius={45} outerRadius={65} paddingAngle={3} dataKey="valor" stroke="none">
                  {demandaPorCategoria.map((e, i) => <Cell key={i} fill={e.cor} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: "12px", fontSize: "12px", color: "var(--foreground)" }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 mt-2">
              {demandaPorCategoria.map(c => (
                <div key={c.nome} className="flex items-center gap-2 text-[12px]">
                  <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: c.cor }} />
                  <span className="text-muted-foreground truncate">{c.nome}</span>
                  <span className="ml-auto font-semibold">{c.valor}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Bars */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="bg-card rounded-2xl p-5 lg:p-6 border min-w-0">
            <h2 className="text-[15px] font-semibold mb-4">Apoio por Bairro</h2>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={apoioPorBairro} layout="vertical" margin={{ top: 0, right: 5, left: 0, bottom: 0 }}>
                <CartesianGrid stroke="var(--border)" horizontal={false} />
                <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="bairro" width={80} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: "12px", fontSize: "12px", color: "var(--foreground)" }} formatter={(value: any) => [`${value}%`, "Apoio"]} />
                <Bar dataKey="apoio" radius={[0, 8, 8, 0]} maxBarSize={16}>
                  {apoioPorBairro.map((e, i) => <Cell key={i} fill={e.apoio >= 70 ? "#30d158" : e.apoio >= 50 ? "#ff9f0a" : "#ff453a"} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Activities */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="bg-card rounded-2xl p-5 lg:p-6 border min-w-0 md:col-span-2 lg:col-span-1">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-[15px] font-semibold">Atividade Recente</h2>
              <Activity className="h-4 w-4 text-muted-foreground/40" />
            </div>
            <div className="space-y-0.5">
              {atividadesRecentes.map((a, i) => {
                const icons: Record<string, { el: React.ElementType; c: string }> = {
                  eleitor: { el: Users, c: "text-chart-1" },
                  atendimento: { el: MessageSquare, c: "text-[#30d158]" },
                  demanda: { el: Target, c: "text-chart-4" },
                  campanha: { el: Send, c: "text-chart-2" },
                  ia: { el: Bot, c: "text-chart-5" },
                }
                const { el: Icon, c } = icons[a.tipo] || icons.eleitor
                return (
                  <motion.div key={a.id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 + i * 0.05, duration: 0.3 }}
                    className="flex items-start gap-3 py-2.5 -mx-2 px-2 rounded-xl hover:bg-muted/50 transition-colors cursor-pointer">
                    <div className="h-7 w-7 rounded-lg bg-muted flex items-center justify-center shrink-0 mt-0.5">
                      <Icon className={`h-3.5 w-3.5 ${c}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[13px] text-foreground/90 leading-snug">{a.descricao}</p>
                      <p className="text-[11px] text-muted-foreground/60 mt-0.5 flex items-center gap-1"><Clock className="h-2.5 w-2.5" />{a.tempo}</p>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </motion.div>
        </div>

        {/* Footer */}
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }}
          className="text-center text-[10px] text-muted-foreground/40 pt-4 pb-6 tracking-wider">
          powered by <span className="font-semibold text-muted-foreground/60">operah</span> & <span className="font-semibold text-muted-foreground/60">alepe</span>
        </motion.p>
      </div>
    </div>
  )
}
