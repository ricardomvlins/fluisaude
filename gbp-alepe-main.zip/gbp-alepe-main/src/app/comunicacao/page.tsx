import { Card, CardContent } from "@/components/ui/card"
import { construction } from "@/lib/module-pages"

export default function ComunicacaoPage() { return construction("Comunicação", "Disparo de mídia, campanhas e templates multicanal", "📡") }
