"use client"

import { useState } from "react"
import { User, Building2, Phone, Mail, Globe, MapPin, Camera, Save, Shield, Bell, Palette, Database, Key, Instagram, Twitter, Facebook } from "lucide-react"
import { useToast } from "@/components/toast"

const tabs = [
    { id: "perfil", label: "Perfil", icon: User },
    { id: "conta", label: "Conta", icon: Shield },
    { id: "notificacoes", label: "Notificações", icon: Bell },
    { id: "plano", label: "Plano", icon: Database },
]

export default function ConfiguracoesPage() {
    const [activeTab, setActiveTab] = useState("perfil")
    const [saving, setSaving] = useState(false)
    const { toast } = useToast()

    const [perfil, setPerfil] = useState({
        nome: "Cauã Rego",
        partido: "PSB",
        numero: "40123",
        cargo: "Vereador",
        cidade: "Recife",
        estado: "PE",
        telefone: "(81) 99999-9999",
        email: "caua@operah.com.br",
        site: "www.cauarego.com.br",
        instagram: "@cauarego",
        twitter: "@cauarego",
        facebook: "cauaregopolitico",
        bio: "Vereador de Recife, comprometido com a transformação da cidade através de políticas públicas eficientes em saúde, educação e segurança.",
    })

    const save = () => {
        setSaving(true)
        setTimeout(() => { setSaving(false); toast("Perfil salvo com sucesso!") }, 800)
    }

    const up = (k: keyof typeof perfil, v: string) => setPerfil(p => ({ ...p, [k]: v }))

    return (
        <div className="p-6 lg:p-8 xl:p-10 max-w-[1000px] mx-auto page-enter">
            <div className="mb-8">
                <h1 className="text-[28px] lg:text-[32px] font-bold tracking-tight">Configurações</h1>
                <p className="text-[13px] text-muted-foreground mt-1">Gerencie seu perfil e preferências</p>
            </div>

            <div className="flex gap-6">
                {/* Tabs */}
                <div className="hidden md:block w-48 shrink-0">
                    <div className="space-y-0.5 sticky top-20">
                        {tabs.map(t => (
                            <button key={t.id} onClick={() => setActiveTab(t.id)}
                                className={`flex items-center gap-2.5 w-full px-3 py-2.5 rounded-xl text-[13px] transition-all ${activeTab === t.id ? "bg-muted font-semibold" : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                                    }`}>
                                <t.icon className="h-4 w-4" />{t.label}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                    {/* Mobile tabs */}
                    <div className="flex gap-1 mb-6 md:hidden overflow-x-auto">
                        {tabs.map(t => (
                            <button key={t.id} onClick={() => setActiveTab(t.id)}
                                className={`px-3 py-1.5 rounded-full text-[12px] font-medium whitespace-nowrap transition-all ${activeTab === t.id ? "bg-foreground text-background" : "text-muted-foreground hover:bg-muted"
                                    }`}>{t.label}</button>
                        ))}
                    </div>

                    {activeTab === "perfil" && (
                        <div className="space-y-6 animate-appear">
                            {/* Photo */}
                            <div className="bg-card rounded-2xl p-6 border">
                                <h2 className="text-[15px] font-semibold mb-4">Foto de Perfil</h2>
                                <div className="flex items-center gap-5">
                                    <div className="relative group cursor-pointer">
                                        <div className="h-20 w-20 rounded-2xl bg-gradient-to-br from-chart-1 to-chart-2 flex items-center justify-center text-[24px] font-bold text-white">
                                            CR
                                        </div>
                                        <div className="absolute inset-0 bg-black/40 rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                            <Camera className="h-5 w-5 text-white" />
                                        </div>
                                    </div>
                                    <div>
                                        <button onClick={() => toast("Upload de foto disponível em breve!", "info")} className="pill pill-outline h-8 px-3 text-[12px] gap-1.5">
                                            <Camera className="h-3 w-3" /> Alterar Foto
                                        </button>
                                        <p className="text-[11px] text-muted-foreground/60 mt-1.5">JPG ou PNG · Máximo 2MB</p>
                                    </div>
                                </div>
                            </div>

                            {/* Info política */}
                            <div className="bg-card rounded-2xl p-6 border">
                                <h2 className="text-[15px] font-semibold mb-4">Informações Políticas</h2>
                                <div className="grid sm:grid-cols-2 gap-4">
                                    {[
                                        { k: "nome" as const, l: "Nome Completo", icon: User, full: true },
                                        { k: "partido" as const, l: "Partido", icon: Building2 },
                                        { k: "numero" as const, l: "Número de Candidato", icon: Building2 },
                                        { k: "cargo" as const, l: "Cargo", icon: User },
                                        { k: "cidade" as const, l: "Cidade", icon: MapPin },
                                        { k: "estado" as const, l: "Estado", icon: MapPin },
                                    ].map(f => (
                                        <div key={f.k} className={f.full ? "sm:col-span-2" : ""}>
                                            <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1.5 mb-1.5">
                                                <f.icon className="h-3 w-3" /> {f.l}
                                            </label>
                                            <input value={perfil[f.k]} onChange={e => up(f.k, e.target.value)}
                                                className="w-full h-9 px-3 rounded-xl bg-muted border border-border text-[13px] focus:outline-none focus:ring-1 focus:ring-chart-1/30 transition-all" />
                                        </div>
                                    ))}
                                    <div className="sm:col-span-2">
                                        <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Bio</label>
                                        <textarea value={perfil.bio} onChange={e => up("bio", e.target.value)} rows={3}
                                            className="w-full px-3 py-2 rounded-xl bg-muted border border-border text-[13px] focus:outline-none focus:ring-1 focus:ring-chart-1/30 transition-all resize-none" />
                                    </div>
                                </div>
                            </div>

                            {/* Contato */}
                            <div className="bg-card rounded-2xl p-6 border">
                                <h2 className="text-[15px] font-semibold mb-4">Contato e Redes</h2>
                                <div className="grid sm:grid-cols-2 gap-4">
                                    {[
                                        { k: "telefone" as const, l: "Telefone", icon: Phone },
                                        { k: "email" as const, l: "E-mail", icon: Mail },
                                        { k: "site" as const, l: "Website", icon: Globe },
                                        { k: "instagram" as const, l: "Instagram", icon: Instagram },
                                        { k: "twitter" as const, l: "Twitter / X", icon: Twitter },
                                        { k: "facebook" as const, l: "Facebook", icon: Facebook },
                                    ].map(f => (
                                        <div key={f.k}>
                                            <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1.5 mb-1.5">
                                                <f.icon className="h-3 w-3" /> {f.l}
                                            </label>
                                            <input value={perfil[f.k]} onChange={e => up(f.k, e.target.value)}
                                                className="w-full h-9 px-3 rounded-xl bg-muted border border-border text-[13px] focus:outline-none focus:ring-1 focus:ring-chart-1/30 transition-all" />
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Save */}
                            <div className="flex justify-end">
                                <button onClick={save} disabled={saving} className="pill pill-filled h-10 px-6 gap-2 text-[14px]">
                                    {saving ? <span className="flex gap-1">{[0, 100, 200].map(d => <span key={d} className="h-1.5 w-1.5 rounded-full bg-background/50 animate-bounce" style={{ animationDelay: `${d}ms` }} />)}</span>
                                        : <><Save className="h-4 w-4" /> Salvar Alterações</>}
                                </button>
                            </div>
                        </div>
                    )}

                    {activeTab === "conta" && (
                        <div className="space-y-6 animate-appear">
                            <div className="bg-card rounded-2xl p-6 border">
                                <h2 className="text-[15px] font-semibold mb-4">Token de Acesso</h2>
                                <div className="flex items-center gap-3 p-3 rounded-xl bg-muted">
                                    <Key className="h-4 w-4 text-muted-foreground/40 shrink-0" />
                                    <code className="text-[13px] text-muted-foreground font-mono flex-1 truncate">gbp_tk_*****_*****_****</code>
                                    <button onClick={() => toast("Token copiado!")} className="pill pill-outline h-7 px-2.5 text-[11px]">Copiar</button>
                                </div>
                                <p className="text-[11px] text-muted-foreground/60 mt-2">Token gerado pela equipe Operah. Entre em contato para renovar.</p>
                            </div>

                            <div className="bg-card rounded-2xl p-6 border">
                                <h2 className="text-[15px] font-semibold mb-4">Segurança</h2>
                                <div className="space-y-3">
                                    {[
                                        { l: "Autenticação em dois fatores", d: "Adicione uma camada extra de segurança", active: false },
                                        { l: "Sessões ativas", d: "1 dispositivo conectado", active: true },
                                        { l: "Histórico de acesso", d: "Último acesso: hoje às " + new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }), active: true },
                                    ].map(s => (
                                        <div key={s.l} className="flex items-center justify-between p-3 rounded-xl hover:bg-muted/50 transition-colors">
                                            <div><p className="text-[13px] font-medium">{s.l}</p><p className="text-[11px] text-muted-foreground/60 mt-0.5">{s.d}</p></div>
                                            <div className={`h-5 w-9 rounded-full transition-colors cursor-pointer flex items-center ${s.active ? "bg-[#30d158] justify-end" : "bg-muted justify-start"}`}
                                                onClick={() => toast(s.active ? "Desativado" : "Ativado", "info")}>
                                                <div className="h-4 w-4 rounded-full bg-white shadow-sm mx-0.5" />
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === "notificacoes" && (
                        <div className="space-y-6 animate-appear">
                            <div className="bg-card rounded-2xl p-6 border">
                                <h2 className="text-[15px] font-semibold mb-4">Preferências de Notificação</h2>
                                <div className="space-y-3">
                                    {[
                                        { l: "Novas demandas", d: "Receba quando uma nova demanda for cadastrada", active: true },
                                        { l: "Alertas de IA", d: "Insights e recomendações automáticas", active: true },
                                        { l: "Queda de apoio", d: "Alertas quando apoio cair em um bairro", active: true },
                                        { l: "Novos cadastros", d: "Notificar a cada novo eleitor cadastrado", active: false },
                                        { l: "Resumo diário", d: "Relatório consolidado por e-mail às 8h", active: true },
                                        { l: "Eventos da agenda", d: "Lembrete 30 min antes de cada compromisso", active: true },
                                        { l: "Campanhas enviadas", d: "Relatório de entrega de mensagens", active: false },
                                    ].map(s => (
                                        <div key={s.l} className="flex items-center justify-between p-3 rounded-xl hover:bg-muted/50 transition-colors">
                                            <div><p className="text-[13px] font-medium">{s.l}</p><p className="text-[11px] text-muted-foreground/60 mt-0.5">{s.d}</p></div>
                                            <div className={`h-5 w-9 rounded-full transition-colors cursor-pointer flex items-center ${s.active ? "bg-[#30d158] justify-end" : "bg-muted justify-start"}`}
                                                onClick={() => toast(s.active ? "Desativado" : "Ativado", "info")}>
                                                <div className="h-4 w-4 rounded-full bg-white shadow-sm mx-0.5" />
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === "plano" && (
                        <div className="space-y-6 animate-appear">
                            <div className="bg-card rounded-2xl p-6 border">
                                <div className="flex items-center justify-between mb-4">
                                    <div>
                                        <h2 className="text-[15px] font-semibold">Seu Plano</h2>
                                        <p className="text-[12px] text-muted-foreground mt-0.5">Gerenciado pela Operah</p>
                                    </div>
                                    <span className="px-3 py-1 rounded-full bg-chart-2/15 text-chart-2 text-[12px] font-semibold">Pro</span>
                                </div>
                                <div className="grid sm:grid-cols-2 gap-3">
                                    {[
                                        { l: "Eleitores", v: "Até 200.000", used: "125.430" },
                                        { l: "Usuários", v: "10 contas", used: "3 ativos" },
                                        { l: "Armazenamento", v: "50 GB", used: "12.3 GB" },
                                        { l: "IA", v: "Ilimitado", used: "1.247 consultas/mês" },
                                        { l: "Relatórios", v: "PDF + Excel", used: "23 gerados" },
                                        { l: "Suporte", v: "Prioritário", used: "WhatsApp direto" },
                                    ].map(p => (
                                        <div key={p.l} className="p-3 rounded-xl bg-muted">
                                            <div className="flex justify-between items-center mb-1">
                                                <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">{p.l}</p>
                                                <p className="text-[11px] text-muted-foreground/60">{p.v}</p>
                                            </div>
                                            <p className="text-[14px] font-semibold">{p.used}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="bg-card rounded-2xl p-6 border text-center">
                                <p className="text-[13px] text-muted-foreground mb-3">Precisa de mais recursos? Entre em contato.</p>
                                <button onClick={() => toast("Solicitação enviada para suporte@operah.com.br")} className="pill pill-filled h-9 px-5 gap-1.5">
                                    <Mail className="h-3.5 w-3.5" /> Contatar Operah
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}
