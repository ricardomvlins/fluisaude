"use client"

import { useEffect, useRef, useState } from "react"
import { apoioPorBairro } from "@/lib/mock-data"
import { Layers, Search, Download, Target, Eye, ZoomIn, ZoomOut } from "lucide-react"
import { useToast } from "@/components/toast"
import L from "leaflet"
import "leaflet/dist/leaflet.css"

const bairrosCoords: Record<string, [number, number]> = {
    "Boa Viagem": [-8.1195, -34.9005],
    "Casa Forte": [-8.0329, -34.9075],
    "Tejipió": [-8.0652, -34.9452],
    "Afogados": [-8.0622, -34.8982],
    "Ibura": [-8.1080, -34.9285],
    "Derby": [-8.0556, -34.8962],
    "Pina": [-8.0915, -34.8770],
    "Torre": [-8.0446, -34.8983],
}

const camadas = [
    { id: "apoio", label: "Apoio Político", color: "#30d158", active: true },
    { id: "eleitores", label: "Densidade Eleitoral", color: "#5ac8fa", active: true },
    { id: "demandas", label: "Demandas Ativas", color: "#ff453a", active: false },
    { id: "eventos", label: "Eventos/Visitas", color: "#bf5af2", active: false },
    { id: "liderancas", label: "Lideranças", color: "#5e5ce6", active: false },
]

export default function MapaPage() {
    const mapRef = useRef<HTMLDivElement>(null)
    const mapInstance = useRef<L.Map | null>(null)
    const [layers, setLayers] = useState(camadas)
    const [sel, setSel] = useState<typeof apoioPorBairro[0] | null>(null)
    const [search, setSearch] = useState("")
    const { toast } = useToast()

    useEffect(() => {
        if (!mapRef.current || mapInstance.current) return

        const map = L.map(mapRef.current, {
            center: [-8.0576, -34.8710],
            zoom: 13,
            zoomControl: false,
            attributionControl: true,
        })

        L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>',
            subdomains: "abcd",
            maxZoom: 19,
        }).addTo(map)

        apoioPorBairro.forEach(b => {
            const coords = bairrosCoords[b.bairro]
            if (!coords) return
            const color = b.apoio >= 70 ? "#30d158" : b.apoio >= 50 ? "#ff9f0a" : "#ff453a"
            const radius = Math.max(300, b.eleitores / 8)

            L.circle(coords, {
                radius,
                color,
                fillColor: color,
                fillOpacity: 0.2,
                weight: 2,
            }).addTo(map).bindPopup(`
        <div style="font-family:system-ui;min-width:160px">
          <strong style="font-size:14px">${b.bairro}</strong><br/>
          <div style="margin-top:4px;font-size:12px;color:#666">
            Apoio: <strong style="color:${color}">${b.apoio}%</strong><br/>
            Eleitores: <strong>${b.eleitores.toLocaleString("pt-BR")}</strong>
          </div>
        </div>
      `)

            L.marker(coords, {
                icon: L.divIcon({
                    className: "",
                    html: `<div style="background:${color};color:white;font-size:11px;font-weight:700;padding:2px 6px;border-radius:999px;white-space:nowrap;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,0.3)">${b.apoio}%</div>`,
                    iconSize: [40, 20],
                    iconAnchor: [20, 10],
                })
            }).addTo(map)
        })

        mapInstance.current = map
        return () => { map.remove(); mapInstance.current = null }
    }, [])

    const zoom = (dir: "in" | "out") => { mapInstance.current?.[dir === "in" ? "zoomIn" : "zoomOut"]() }

    const filteredBairros = apoioPorBairro.filter(b => b.bairro.toLowerCase().includes(search.toLowerCase()))

    const flyTo = (b: typeof apoioPorBairro[0]) => {
        setSel(b)
        const coords = bairrosCoords[b.bairro]
        if (coords && mapInstance.current) mapInstance.current.flyTo(coords, 15, { duration: 1 })
    }

    return (
        <div className="h-[calc(100vh-3rem)] flex page-enter">
            <div className="flex-1 relative">
                <div ref={mapRef} className="absolute inset-0 z-0" />

                <div className="absolute top-4 left-4 flex flex-col gap-1 z-[1000]">
                    {[{ icon: ZoomIn, fn: () => zoom("in") }, { icon: ZoomOut, fn: () => zoom("out") }].map((b, i) => (
                        <button key={i} onClick={b.fn} className="h-9 w-9 flex items-center justify-center rounded-xl bg-card/90 backdrop-blur border shadow-lg text-muted-foreground hover:text-foreground transition-colors">
                            <b.icon className="h-4 w-4" />
                        </button>
                    ))}
                </div>

                <div className="absolute top-4 left-16 w-64 z-[1000]">
                    <div className="flex items-center gap-2 h-9 px-3 rounded-xl bg-card/90 backdrop-blur border shadow-lg">
                        <Search className="h-3.5 w-3.5 text-muted-foreground/40" />
                        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar bairro..."
                            className="bg-transparent text-[12px] placeholder:text-muted-foreground/40 focus:outline-none w-full" />
                    </div>
                </div>
            </div>

            <div className="w-80 border-l bg-background overflow-y-auto shrink-0 hidden lg:block animate-slide-right">
                <div className="p-5 border-b">
                    <h2 className="text-[14px] font-semibold flex items-center gap-2"><Layers className="h-4 w-4 text-chart-1" /> Camadas</h2>
                    <div className="mt-3 space-y-0.5">
                        {layers.map(l => (
                            <button key={l.id} onClick={() => setLayers(p => p.map(x => x.id === l.id ? { ...x, active: !x.active } : x))}
                                className={`flex items-center gap-2.5 w-full px-3 py-2 rounded-xl text-[13px] transition-all ${l.active ? "bg-muted font-medium" : "text-muted-foreground hover:bg-muted/50"}`}>
                                <div className="h-3 w-3 rounded-full border-2 transition-all" style={{ borderColor: l.color, backgroundColor: l.active ? l.color : "transparent", opacity: l.active ? 1 : 0.3 }} />
                                <span className="flex-1 text-left">{l.label}</span>
                                <Eye className={`h-3 w-3 ${l.active ? "opacity-50" : "opacity-15"}`} />
                            </button>
                        ))}
                    </div>
                </div>

                <div className="p-5">
                    {sel ? (
                        <div className="animate-scale-in">
                            <h3 className="text-[16px] font-bold mb-3">{sel.bairro}</h3>
                            <div className="grid grid-cols-2 gap-3 mb-4">
                                <div className="p-3 rounded-xl bg-muted">
                                    <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">Apoio</p>
                                    <p className={`text-xl font-bold ${sel.apoio >= 70 ? "text-[#30d158]" : sel.apoio >= 50 ? "text-[#ff9f0a]" : "text-[#ff453a]"}`}>{sel.apoio}%</p>
                                </div>
                                <div className="p-3 rounded-xl bg-muted">
                                    <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">Eleitores</p>
                                    <p className="text-xl font-bold">{sel.eleitores.toLocaleString("pt-BR")}</p>
                                </div>
                            </div>
                            <div className="space-y-2">
                                <button onClick={() => toast(`Campanha criada para ${sel.bairro}!`)} className="pill pill-filled h-9 px-4 w-full gap-1.5"><Target className="h-3.5 w-3.5" /> Gerar Campanha</button>
                                <button onClick={() => toast(`Dados de ${sel.bairro} exportados!`)} className="pill pill-outline h-9 px-4 w-full gap-1.5"><Download className="h-3.5 w-3.5" /> Exportar Dados</button>
                            </div>
                            <button onClick={() => setSel(null)} className="text-[12px] text-muted-foreground hover:text-foreground transition-colors mt-3 w-full text-center">← Voltar ao ranking</button>
                        </div>
                    ) : (
                        <div>
                            <h3 className="text-[13px] font-semibold mb-3">Ranking de Apoio</h3>
                            <div className="space-y-0.5">
                                {filteredBairros.map((b, i) => (
                                    <div key={b.bairro} onClick={() => flyTo(b)} className="flex items-center gap-3 cursor-pointer hover:bg-muted p-2.5 rounded-xl transition-colors">
                                        <span className="text-[11px] font-bold text-muted-foreground/40 w-4">{i + 1}</span>
                                        <div className="flex-1">
                                            <p className="text-[13px] font-medium">{b.bairro}</p>
                                            <div className="flex items-center gap-2 mt-1">
                                                <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                                                    <div className={`h-full rounded-full transition-all duration-700 ${b.apoio >= 70 ? "bg-[#30d158]" : b.apoio >= 50 ? "bg-[#ff9f0a]" : "bg-[#ff453a]"}`} style={{ width: `${b.apoio}%` }} />
                                                </div>
                                                <span className="text-[11px] font-semibold text-muted-foreground w-8 text-right">{b.apoio}%</span>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}
