import { construction } from "@/lib/module-pages"
export default function ProjetosPage() { return construction("Projetos & Ações", "Roadmap, cronogramas e indicadores de projetos políticos", "🏗️") }
