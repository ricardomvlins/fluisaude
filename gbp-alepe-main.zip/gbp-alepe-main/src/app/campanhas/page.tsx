import { construction } from "@/lib/module-pages"
export default function CampanhasPage() { return construction("Campanhas", "Organização de campanhas políticas e ações temáticas", "🎯") }
