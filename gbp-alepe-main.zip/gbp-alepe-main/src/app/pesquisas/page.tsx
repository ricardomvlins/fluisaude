import { construction } from "@/lib/module-pages"
export default function PesquisasPage() { return construction("Pesquisas", "Pesquisas quantitativas, qualitativas e análise de sentimento", "📊") }
