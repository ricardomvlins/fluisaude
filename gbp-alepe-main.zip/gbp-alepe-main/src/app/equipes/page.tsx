import { construction } from "@/lib/module-pages"
export default function EquipesPage() { return construction("Equipes & Lideranças", "Gestão de equipe interna, lideranças comunitárias e coordenadores", "👥") }
