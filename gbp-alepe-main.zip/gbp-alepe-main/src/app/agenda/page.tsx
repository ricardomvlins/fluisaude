"use client"

import { useState } from "react"
import { agenda } from "@/lib/mock-data"
import { Calendar, MapPin, Clock, ChevronLeft, ChevronRight, Plus, Users, Car, Megaphone, Phone, Video, Mic } from "lucide-react"
import { useToast } from "@/components/toast"

const tipoConfig: Record<string, { icon: React.ElementType; color: string }> = {
    reuniao: { icon: Users, color: "text-[#5ac8fa]" }, visita: { icon: Car, color: "text-[#30d158]" },
    evento: { icon: Megaphone, color: "text-[#bf5af2]" }, ligacao: { icon: Phone, color: "text-[#ff9f0a]" },
    campanha: { icon: Video, color: "text-[#ff453a]" }, entrevista: { icon: Mic, color: "text-[#5e5ce6]" },
}
const statusC: Record<string, string> = { confirmado: "bg-[#30d158]/15 text-[#30d158]", pendente: "bg-[#ff9f0a]/15 text-[#ff9f0a]", cancelado: "bg-[#ff453a]/15 text-[#ff453a]" }
const days = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"]

export default function AgendaPage() {
    const { toast } = useToast()
    const [selDay, setSelDay] = useState<number | null>(null)
    const hoje = new Date()
    const daysInMonth = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0).getDate()
    const first = new Date(hoje.getFullYear(), hoje.getMonth(), 1).getDay()
    const cal = Array.from({ length: 42 }, (_, i) => { const d = i - first + 1; return d >= 1 && d <= daysInMonth ? d : null })

    const eventsOn = (day: number) => {
        const ds = `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
        return agenda.filter(e => e.data === ds)
    }

    return (
        <div className="p-6 lg:p-8 xl:p-10 max-w-[1440px] mx-auto page-enter">
            <div className="flex items-center justify-between mb-8">
                <div>
                    <h1 className="text-[32px] font-bold tracking-tight text-foreground">Agenda</h1>
                    <p className="text-[14px] text-muted-foreground mt-1">Compromissos e eventos</p>
                </div>
                <button onClick={() => toast("Novo evento criado no dia de hoje!", "success")} className="pill pill-filled h-9 px-4 gap-1.5"><Plus className="h-3.5 w-3.5" /> Novo Evento</button>
            </div>

            <div className="grid gap-5 lg:grid-cols-3">
                <div className="lg:col-span-2 bg-card rounded-2xl p-6 border border-border animate-appear">
                    <div className="flex items-center justify-between mb-5">
                        <h2 className="text-[17px] font-semibold text-foreground flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-[#5ac8fa]" />
                            {hoje.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}
                        </h2>
                        <div className="flex gap-1">
                            {[{ I: ChevronLeft, d: "Mês anterior" }, { I: ChevronRight, d: "Próximo mês" }].map((b, i) => <button key={i} onClick={() => toast(b.d, "info")} className="h-7 w-7 flex items-center justify-center rounded-lg hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"><b.I className="h-4 w-4" /></button>)}
                        </div>
                    </div>
                    <div className="grid grid-cols-7 gap-0.5">
                        {days.map(d => <div key={d} className="text-center text-[10px] font-medium text-muted-foreground/60 uppercase tracking-wider py-2">{d}</div>)}
                        {cal.map((dia, i) => {
                            const isToday = dia === hoje.getDate()
                            const evts = dia ? eventsOn(dia) : []
                            return (
                                <div key={i} className={`relative min-h-[72px] p-1.5 rounded-xl transition-colors cursor-pointer ${dia === null ? "" : isToday ? "bg-muted/50 ring-1 ring-border" : "hover:bg-muted/30"
                                    }`}>
                                    {dia && <>
                                        <span className={`text-[12px] ${isToday ? "text-foreground font-bold" : "text-muted-foreground"}`}>{dia}</span>
                                        {evts.length > 0 && <div className="mt-1 space-y-0.5">
                                            {evts.slice(0, 2).map(e => {
                                                const c = tipoConfig[e.tipo]
                                                return <div key={e.id} className={`text-[9px] px-1 py-0.5 rounded-md bg-muted/50 ${c.color} font-medium truncate`}>{e.hora.slice(0, 5)}</div>
                                            })}
                                            {evts.length > 2 && <div className="text-[8px] text-muted-foreground/60">+{evts.length - 2}</div>}
                                        </div>}
                                    </>}
                                </div>
                            )
                        })}
                    </div>
                </div>

                <div className="bg-card rounded-2xl p-5 border border-border animate-appear" style={{ animationDelay: "0.1s" }}>
                    <h2 className="text-[15px] font-semibold text-foreground mb-4">Próximos</h2>
                    <div className="space-y-1.5">
                        {agenda.map(e => {
                            const c = tipoConfig[e.tipo]; const I = c.icon
                            return (
                                <div key={e.id} className="p-3 rounded-xl hover:bg-muted transition-all cursor-pointer border border-transparent hover:border-border">
                                    <div className="flex items-start gap-3">
                                        <I className={`h-4 w-4 mt-0.5 shrink-0 ${c.color}`} />
                                        <div className="flex-1 min-w-0">
                                            <p className="text-[13px] font-medium text-foreground leading-snug">{e.titulo}</p>
                                            <div className="flex items-center gap-3 mt-1 text-[11px] text-muted-foreground/60">
                                                <span className="flex items-center gap-1"><Clock className="h-2.5 w-2.5" />{e.hora}</span>
                                                <span className="flex items-center gap-1"><MapPin className="h-2.5 w-2.5" />{e.local.split(",")[0]}</span>
                                            </div>
                                            <div className="flex items-center gap-2 mt-1.5">
                                                <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-medium ${statusC[e.status]}`}>{e.status}</span>
                                                <span className="text-[10px] text-muted-foreground/40">{new Date(e.data).toLocaleDateString("pt-BR", { day: "numeric", month: "short" })}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>
        </div>
    )
}
