import { construction } from "@/lib/module-pages"
export default function AjudaPage() { return construction("Central de Ajuda", "Onboarding, tutoriais, base de conhecimento e suporte", "❓") }
