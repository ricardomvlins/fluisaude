"use client"

import { TrendingUp, TrendingDown, AlertTriangle, Lightbulb, BarChart3, Zap, ChevronRight } from "lucide-react"
import { useToast } from "@/components/toast"

const swot = {
    forcas: ["Base sólida em Boa Viagem e Casa Forte", "Forte presença em saúde e educação", "IA operacional", "156 lideranças ativas"],
    fraquezas: ["Baixa presença digital jovem", "Tempo de resposta: 4.2d", "Cobertura limitada Afogados/Ibura", "Integração social incompleta"],
    oportunidades: ["+200 cadastros/mês Boa Viagem", "Saúde como porta de entrada", "Lives para jovens", "Parcerias Ibura"],
    ameacas: ["Queda apoio Afogados (-4%)", "Concorrente no Ibura", "Demandas pendentes", "3 demandas vencendo"],
}

const cenarios = [
    { tipo: "Conservador", votos: "85 mil", apoio: "72%", c: "border-[#ff9f0a]/20 text-[#ff9f0a]" },
    { tipo: "Provável", votos: "102 mil", apoio: "78%", c: "border-[#5ac8fa]/20 text-[#5ac8fa]" },
    { tipo: "Agressivo", votos: "125 mil", apoio: "85%", c: "border-[#30d158]/20 text-[#30d158]" },
]

const prios = [
    { a: "Visita urgente a Afogados", g: "+2%" },
    { a: "WhatsApp comerciantes Boa Viagem", g: "+150" },
    { a: "Resolver demandas saúde Tejipió", g: "+3%" },
    { a: "2 lives para público jovem", g: "+23%" },
    { a: "Reunião 5 lideranças Ibura", g: "+5%" },
]

export default function EstrategiaPage() {
    const { toast } = useToast()
    return (
        <div className="p-6 lg:p-8 xl:p-10 max-w-[1440px] mx-auto page-enter space-y-8">
            <div>
                <h1 className="text-[32px] font-bold tracking-tight text-foreground">Estratégia</h1>
                <p className="text-[14px] text-muted-foreground mt-1">Análise SWOT, cenários e prioridades</p>
            </div>

            <div className="grid gap-4 md:grid-cols-2 stagger">
                {[
                    { t: "Forças", items: swot.forcas, icon: TrendingUp, color: "#30d158" },
                    { t: "Fraquezas", items: swot.fraquezas, icon: TrendingDown, color: "#ff453a" },
                    { t: "Oportunidades", items: swot.oportunidades, icon: Lightbulb, color: "#5ac8fa" },
                    { t: "Ameaças", items: swot.ameacas, icon: AlertTriangle, color: "#ff9f0a" },
                ].map(q => (
                    <div key={q.t} className="bg-card rounded-2xl p-5 border border-border hover:border-border transition-all" style={{ borderLeftWidth: "3px", borderLeftColor: q.color }}>
                        <h3 className="text-[13px] font-semibold flex items-center gap-2 mb-3" style={{ color: q.color }}><q.icon className="h-4 w-4" /> {q.t}</h3>
                        <ul className="space-y-2">{q.items.map((item, i) => (
                            <li key={i} className="flex items-start gap-2 text-[13px] text-foreground/90">
                                <span className="h-1.5 w-1.5 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: q.color, opacity: 0.6 }} />{item}
                            </li>
                        ))}</ul>
                    </div>
                ))}
            </div>

            <div className="bg-card rounded-2xl p-6 border border-border animate-appear">
                <h2 className="text-[17px] font-semibold text-foreground flex items-center gap-2 mb-5"><BarChart3 className="h-4 w-4 text-[#5ac8fa]" /> Cenários</h2>
                <div className="grid md:grid-cols-3 gap-4">
                    {cenarios.map(c => (
                        <div key={c.tipo} onClick={() => toast(`Cenário ${c.tipo}: ${c.votos} votos estimados`, "info")} className={`p-5 rounded-2xl border-2 bg-muted hover:bg-accent transition-all cursor-pointer ${c.c}`}>
                            <p className="text-[11px] font-semibold uppercase tracking-wider opacity-60 mb-2">{c.tipo}</p>
                            <p className="text-[28px] font-bold text-foreground">{c.votos}</p>
                            <p className="text-[13px] font-medium mt-1">Apoio: {c.apoio}</p>
                        </div>
                    ))}
                </div>
            </div>

            <div className="bg-card rounded-2xl border border-border overflow-hidden animate-appear" style={{ animationDelay: "0.1s" }}>
                <div className="px-6 py-4 border-b border-border"><h2 className="text-[17px] font-semibold text-foreground flex items-center gap-2"><Zap className="h-4 w-4 text-[#ff9f0a]" /> Prioridades</h2></div>
                {prios.map((p, i) => (
                    <div key={i} onClick={() => toast(`Prioridade: ${p.a} → Meta: ${p.g}`, "info")} className="flex items-center gap-4 px-6 py-3.5 border-b border-border/50 last:border-0 hover:bg-muted/30 transition-colors cursor-pointer group">
                        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-foreground/5 text-foreground text-[12px] font-bold">{i + 1}</span>
                        <p className="flex-1 text-[13px] font-medium text-foreground">{p.a}</p>
                        <span className="text-[12px] font-medium text-[#30d158] bg-[#30d158]/10 px-2 py-0.5 rounded-full">{p.g}</span>
                        <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/40 group-hover:text-foreground transition-colors" />
                    </div>
                ))}
            </div>
        </div>
    )
}
