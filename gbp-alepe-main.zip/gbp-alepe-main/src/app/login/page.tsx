"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Key, ArrowRight, Eye, EyeOff, Shield, Zap, Users } from "lucide-react"

export default function LoginPage() {
    const [token, setToken] = useState("")
    const [showToken, setShowToken] = useState(false)
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState("")
    const router = useRouter()

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault()
        if (!token.trim()) { setError("Insira seu token de acesso"); return }
        setLoading(true); setError("")
        setTimeout(() => {
            localStorage.setItem("gbp_token", token)
            localStorage.setItem("gbp_auth", "true")
            router.push("/")
        }, 1200)
    }

    return (
        <div className="min-h-screen flex bg-background">
            {/* Left — Form */}
            <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
                <div className="w-full max-w-[380px] animate-appear">
                    <Image src="/alepe-logo.png" alt="ALEPE" width={56} height={56} className="rounded-2xl mb-6 shadow-md" />
                    <h1 className="text-[28px] font-bold tracking-tight leading-tight">Acesse sua conta</h1>
                    <p className="text-[14px] text-muted-foreground mt-1.5 leading-relaxed">
                        Entre com o token fornecido pela sua equipe de administração.
                    </p>

                    <form onSubmit={handleLogin} className="mt-8 space-y-4">
                        <div>
                            <label className="text-[12px] font-medium text-muted-foreground block mb-2">Token de Acesso</label>
                            <div className="relative">
                                <Key className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/40" />
                                <input type={showToken ? "text" : "password"} value={token} onChange={e => { setToken(e.target.value); setError("") }}
                                    placeholder="gbp_tk_..."
                                    className="w-full h-11 pl-10 pr-10 rounded-xl bg-muted border border-border text-[14px] focus:outline-none focus:ring-2 focus:ring-chart-1/30 focus:border-chart-1/50 transition-all placeholder:text-muted-foreground/30"
                                    autoFocus />
                                <button type="button" onClick={() => setShowToken(!showToken)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground/30 hover:text-muted-foreground transition-colors">
                                    {showToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                </button>
                            </div>
                            {error && <p className="text-[12px] text-destructive mt-1.5">{error}</p>}
                        </div>

                        <button type="submit" disabled={loading}
                            className="w-full h-11 rounded-xl bg-foreground text-background font-semibold text-[14px] hover:opacity-90 transition-all disabled:opacity-50 flex items-center justify-center gap-2">
                            {loading ? (
                                <span className="flex gap-1.5">
                                    {[0, 150, 300].map(d => <span key={d} className="h-2 w-2 rounded-full bg-background/50 animate-bounce" style={{ animationDelay: `${d}ms` }} />)}
                                </span>
                            ) : (<>Entrar <ArrowRight className="h-4 w-4" /></>)}
                        </button>
                    </form>

                    <p className="text-center text-[11px] text-muted-foreground/40 mt-10 tracking-wider">
                        powered by <span className="font-semibold text-muted-foreground/60">operah</span> & <span className="font-semibold text-muted-foreground/60">alepe</span>
                    </p>
                </div>
            </div>

            {/* Right — Features panel */}
            <div className="hidden lg:flex flex-col justify-center w-[420px] bg-muted/30 border-l px-10 py-12">
                <div className="animate-appear" style={{ animationDelay: "0.15s" }}>
                    <h2 className="text-[20px] font-bold tracking-tight mb-2">ALEPE Política</h2>
                    <p className="text-[13px] text-muted-foreground leading-relaxed mb-8">Plataforma completa de gestão de base política para parlamentares e equipes.</p>

                    <div className="space-y-5">
                        {[
                            { icon: Users, title: "CRM Eleitoral", desc: "Gerencie relacionamentos com eleitores, lideranças e segmentos de forma organizada." },
                            { icon: Zap, title: "Inteligência Operah IA", desc: "Estratégias de campanha, triangulação de perfis e insights automáticos por IA." },
                            { icon: Shield, title: "Segurança e Controle", desc: "Dados protegidos, acesso por token, auditoria completa de atividades." },
                        ].map(f => (
                            <div key={f.title} className="flex gap-3.5">
                                <div className="h-9 w-9 rounded-xl bg-background border flex items-center justify-center shrink-0">
                                    <f.icon className="h-4 w-4 text-muted-foreground" />
                                </div>
                                <div>
                                    <p className="text-[13px] font-semibold">{f.title}</p>
                                    <p className="text-[12px] text-muted-foreground/70 leading-relaxed mt-0.5">{f.desc}</p>
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="mt-10 pt-6 border-t">
                        <p className="text-[11px] text-muted-foreground/50">
                            Precisa de acesso? Entre em contato com a equipe de administração para solicitar seu token de acordo com o plano contratado.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    )
}
