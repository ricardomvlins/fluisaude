"use client"

import { useState } from "react"
import { eleitores, type Eleitor } from "@/lib/mock-data"
import { Search, Download, Plus, Phone, Mail, X, ArrowUpDown, Users, TrendingUp, UserPlus, Star, ChevronRight, Copy, FileDown } from "lucide-react"
import { CadastroEleitorModal } from "@/components/cadastro-eleitor"
import { useToast } from "@/components/toast"

function Badge({ children, color }: { children: React.ReactNode; color: string }) {
    return <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium ${color}`}>{children}</span>
}

const apoioColor: Record<string, string> = {
    Alto: "bg-[#30d158]/15 text-[#30d158]",
    Médio: "bg-[#ff9f0a]/15 text-[#ff9f0a]",
    Baixo: "bg-[#ff453a]/15 text-[#ff453a]",
    Indeciso: "bg-muted-foreground/15 text-muted-foreground",
}

export default function CRMPage() {
    const [search, setSearch] = useState("")
    const [filter, setFilter] = useState<string | null>(null)
    const [sel, setSel] = useState<Eleitor | null>(null)
    const [showCadastro, setShowCadastro] = useState(false)
    const [sortKey, setSortKey] = useState<"nome" | "score" | "bairro" | "apoio">("nome")
    const [sortDir, setSortDir] = useState<"asc" | "desc">("asc")
    const { toast } = useToast()

    const filtered = eleitores.filter(e => {
        const q = search.toLowerCase()
        const m = e.nome.toLowerCase().includes(q) || e.bairro.toLowerCase().includes(q) || e.telefone.includes(q)
        return m && (!filter || e.apoio === filter)
    }).sort((a, b) => {
        const dir = sortDir === "asc" ? 1 : -1
        if (sortKey === "score") return (a.score - b.score) * dir
        return a[sortKey].localeCompare(b[sortKey]) * dir
    })

    const toggleSort = (key: typeof sortKey) => {
        if (sortKey === key) setSortDir(d => d === "asc" ? "desc" : "asc")
        else { setSortKey(key); setSortDir("asc") }
    }

    const exportCSV = () => {
        const headers = ["Nome", "Telefone", "Email", "Bairro", "Apoio", "Score", "Segmento", "Status"]
        const rows = filtered.map(e => [e.nome, e.telefone, e.email, e.bairro, e.apoio, e.score, e.segmento, e.status])
        const csv = [headers.join(","), ...rows.map(r => r.join(","))].join("\n")
        const blob = new Blob([csv], { type: "text/csv" })
        const url = URL.createObjectURL(blob)
        const a = document.createElement("a"); a.href = url; a.download = `crm-eleitoral-${new Date().toISOString().slice(0, 10)}.csv`; a.click()
        URL.revokeObjectURL(url)
        toast(`Exportados ${filtered.length} eleitores para CSV`)
    }

    const copyPhone = (phone: string) => { navigator.clipboard.writeText(phone); toast("Telefone copiado!") }
    const copyEmail = (email: string) => { navigator.clipboard.writeText(email); toast("E-mail copiado!") }

    return (
        <div className="p-6 lg:p-8 xl:p-10 max-w-[1440px] mx-auto page-enter">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                <div>
                    <h1 className="text-[28px] lg:text-[32px] font-bold tracking-tight">CRM Eleitoral</h1>
                    <p className="text-[13px] text-muted-foreground mt-1">Base de relacionamento político</p>
                </div>
                <div className="flex gap-2">
                    <button onClick={exportCSV} className="pill pill-outline h-9 px-4 gap-1.5"><FileDown className="h-3.5 w-3.5" /> Exportar</button>
                    <button onClick={() => setShowCadastro(true)} className="pill pill-filled h-9 px-4 gap-1.5"><Plus className="h-3.5 w-3.5" /> Novo Eleitor</button>
                </div>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
                {[
                    { l: "Total", v: eleitores.length, icon: Users, c: "text-chart-1" },
                    { l: "Ativos", v: eleitores.filter(x => x.status === "Ativo").length, icon: TrendingUp, c: "text-[#30d158]" },
                    { l: "Novos", v: eleitores.filter(x => x.status === "Novo").length, icon: UserPlus, c: "text-chart-2" },
                    { l: "Score Médio", v: Math.round(eleitores.reduce((a, e) => a + e.score, 0) / eleitores.length), icon: Star, c: "text-chart-4" },
                ].map(s => (
                    <div key={s.l} className="bg-card rounded-2xl p-4 border hover:border-foreground/10 transition-all flex items-center gap-3 cursor-pointer">
                        <div className="h-9 w-9 rounded-xl bg-muted flex items-center justify-center"><s.icon className={`h-4 w-4 ${s.c}`} /></div>
                        <div>
                            <p className="text-[18px] lg:text-[20px] font-bold">{s.v.toLocaleString("pt-BR")}</p>
                            <p className="text-[11px] text-muted-foreground/60 font-medium">{s.l}</p>
                        </div>
                    </div>
                ))}
            </div>

            <div className="flex gap-4">
                <div className={`flex-1 bg-card rounded-2xl border overflow-hidden transition-all min-w-0 ${sel ? "lg:max-w-[58%]" : ""}`}>
                    <div className="flex items-center gap-3 p-4 border-b">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                            <Search className="h-3.5 w-3.5 text-muted-foreground/40 shrink-0" />
                            <input placeholder="Buscar nome, bairro ou telefone..." value={search} onChange={(e) => setSearch(e.target.value)}
                                className="bg-transparent text-[13px] placeholder:text-muted-foreground/40 focus:outline-none w-full min-w-0" />
                        </div>
                        <div className="flex gap-1 shrink-0">
                            {["Alto", "Médio", "Baixo", "Indeciso"].map(a => (
                                <button key={a} onClick={() => setFilter(filter === a ? null : a)}
                                    className={`px-2.5 py-1 rounded-full text-[11px] font-medium transition-all ${filter === a ? "bg-foreground text-background" : "text-muted-foreground hover:bg-muted"
                                        }`}>{a}</button>
                            ))}
                        </div>
                    </div>

                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead>
                                <tr className="border-b">
                                    {[{ k: "nome" as const, l: "Nome" }, { k: "bairro" as const, l: "Bairro" }, { k: "apoio" as const, l: "Apoio" }, { k: "score" as const, l: "Score" }].map(h => (
                                        <th key={h.k} className="text-left px-4 py-2.5 text-[11px] font-medium text-muted-foreground/60 uppercase tracking-[0.08em]">
                                            <button onClick={() => toggleSort(h.k)} className="flex items-center gap-1 hover:text-foreground transition-colors">
                                                {h.l}<ArrowUpDown className={`h-2.5 w-2.5 ${sortKey === h.k ? "text-foreground" : ""}`} />
                                            </button>
                                        </th>
                                    ))}
                                    <th className="text-left px-4 py-2.5 text-[11px] font-medium text-muted-foreground/60 uppercase tracking-[0.08em]">Segmento</th>
                                    <th className="text-left px-4 py-2.5 text-[11px] font-medium text-muted-foreground/60 uppercase tracking-[0.08em]">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filtered.map(e => (
                                    <tr key={e.id} onClick={() => setSel(sel?.id === e.id ? null : e)}
                                        className={`border-b border-border/50 cursor-pointer transition-colors ${sel?.id === e.id ? "bg-muted/40" : "hover:bg-muted/30"}`}>
                                        <td className="px-4 py-3">
                                            <div className="flex items-center gap-3">
                                                <div className="h-8 w-8 rounded-full bg-gradient-to-br from-chart-1/20 to-chart-2/20 flex items-center justify-center text-[11px] font-bold shrink-0">
                                                    {e.nome.split(" ").map(n => n[0]).slice(0, 2).join("")}
                                                </div>
                                                <div className="min-w-0">
                                                    <p className="text-[13px] font-medium truncate">{e.nome}</p>
                                                    <p className="text-[11px] text-muted-foreground/60 truncate">{e.email}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-4 py-3 text-[13px] text-muted-foreground">{e.bairro}</td>
                                        <td className="px-4 py-3"><Badge color={apoioColor[e.apoio]}>{e.apoio}</Badge></td>
                                        <td className="px-4 py-3">
                                            <div className="flex items-center gap-2">
                                                <div className="w-10 h-1.5 rounded-full bg-muted overflow-hidden">
                                                    <div className={`h-full rounded-full transition-all duration-500 ${e.score >= 80 ? "bg-[#30d158]" : e.score >= 50 ? "bg-[#ff9f0a]" : "bg-[#ff453a]"}`} style={{ width: `${e.score}%` }} />
                                                </div>
                                                <span className="text-[12px] font-medium text-muted-foreground tabular-nums">{e.score}</span>
                                            </div>
                                        </td>
                                        <td className="px-4 py-3 text-[13px] text-muted-foreground">{e.segmento}</td>
                                        <td className="px-4 py-3">
                                            <span className="flex items-center gap-1.5 text-[12px] text-muted-foreground">
                                                <span className={`h-1.5 w-1.5 rounded-full ${e.status === "Ativo" ? "bg-[#30d158]" : e.status === "Novo" ? "bg-chart-1" : "bg-muted-foreground/40"}`} />
                                                {e.status}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="flex items-center justify-between px-4 py-3 border-t">
                        <p className="text-[12px] text-muted-foreground/60">{filtered.length} de {eleitores.length} eleitores</p>
                    </div>
                </div>

                {sel && (
                    <div className="hidden lg:flex flex-col w-[360px] bg-card rounded-2xl border animate-slide-right overflow-hidden shrink-0">
                        <div className="p-5 border-b shrink-0">
                            <div className="flex items-start justify-between">
                                <div className="flex items-center gap-3">
                                    <div className="h-12 w-12 rounded-full bg-gradient-to-br from-chart-1/20 to-chart-2/20 flex items-center justify-center text-[16px] font-bold">
                                        {sel.nome.split(" ").map(n => n[0]).slice(0, 2).join("")}
                                    </div>
                                    <div>
                                        <h3 className="text-[16px] font-semibold">{sel.nome}</h3>
                                        <p className="text-[12px] text-muted-foreground/60">{sel.bairro}, {sel.cidade}</p>
                                    </div>
                                </div>
                                <button onClick={() => setSel(null)} className="text-muted-foreground/60 hover:text-foreground transition-colors p-1"><X className="h-4 w-4" /></button>
                            </div>
                        </div>
                        <div className="p-5 space-y-5 overflow-y-auto flex-1">
                            <div className="flex gap-2">
                                <Badge color={apoioColor[sel.apoio]}>{sel.apoio}</Badge>
                                <span className="text-[12px] text-muted-foreground flex items-center gap-1">
                                    <span className={`h-1.5 w-1.5 rounded-full ${sel.status === "Ativo" ? "bg-[#30d158]" : "bg-muted-foreground/40"}`} /> {sel.status}
                                </span>
                            </div>

                            <div className="grid grid-cols-2 gap-3">
                                <div className="p-3 rounded-xl bg-muted"><p className="text-[10px] text-muted-foreground/60 font-medium uppercase tracking-wider">Score</p><p className="text-[24px] font-bold mt-0.5">{sel.score}</p></div>
                                <div className="p-3 rounded-xl bg-muted"><p className="text-[10px] text-muted-foreground/60 font-medium uppercase tracking-wider">Idade</p><p className="text-[24px] font-bold mt-0.5">{sel.idade}</p></div>
                            </div>

                            <div className="space-y-1">
                                <p className="text-[10px] text-muted-foreground/60 font-medium uppercase tracking-wider mb-2">Contato</p>
                                <button onClick={() => copyPhone(sel.telefone)} className="flex items-center gap-2.5 p-2.5 rounded-xl hover:bg-muted transition-colors cursor-pointer w-full text-left group">
                                    <Phone className="h-4 w-4 text-muted-foreground/60" /><span className="text-[13px] flex-1">{sel.telefone}</span><Copy className="h-3 w-3 text-muted-foreground/40 opacity-0 group-hover:opacity-100 transition-opacity" />
                                </button>
                                <button onClick={() => copyEmail(sel.email)} className="flex items-center gap-2.5 p-2.5 rounded-xl hover:bg-muted transition-colors cursor-pointer w-full text-left group">
                                    <Mail className="h-4 w-4 text-muted-foreground/60" /><span className="text-[13px] flex-1">{sel.email}</span><Copy className="h-3 w-3 text-muted-foreground/40 opacity-0 group-hover:opacity-100 transition-opacity" />
                                </button>
                            </div>

                            <div>
                                <p className="text-[10px] text-muted-foreground/60 font-medium uppercase tracking-wider mb-2">Tags</p>
                                <div className="flex flex-wrap gap-1.5">
                                    {sel.tags.map(t => <span key={t} className="px-2 py-0.5 rounded-full bg-foreground/5 text-[11px] font-medium">{t}</span>)}
                                </div>
                            </div>

                            <div className="space-y-1.5">
                                <p className="text-[10px] text-muted-foreground/60 font-medium uppercase tracking-wider mb-2">Detalhes</p>
                                {[["Segmento", sel.segmento], ["Liderança", sel.lideranca], ["Gênero", sel.genero === "M" ? "Masculino" : "Feminino"], ["Última interação", sel.ultimaInteracao]].map(([k, v]) => (
                                    <div key={k} className="flex justify-between py-1.5 border-b">
                                        <span className="text-[13px] text-muted-foreground">{k}</span>
                                        <span className="text-[13px] font-medium">{v}</span>
                                    </div>
                                ))}
                            </div>

                            <button onClick={() => toast("Função disponível em breve!", "info")} className="pill pill-outline h-9 px-4 w-full gap-1.5 mt-2">
                                <ChevronRight className="h-3.5 w-3.5" /> Ver Perfil Completo
                            </button>
                        </div>
                    </div>
                )}
            </div>
            <CadastroEleitorModal open={showCadastro} onClose={() => setShowCadastro(false)} />
        </div>
    )
}
