import { construction } from "@/lib/module-pages"
export default function OficiosPage() { return construction("Ofícios & Requerimentos", "Controle de produção, protocolo e acompanhamento institucional", "📋") }
