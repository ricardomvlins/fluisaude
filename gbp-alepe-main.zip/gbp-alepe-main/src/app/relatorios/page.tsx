import { construction } from "@/lib/module-pages"
export default function RelatoriosPage() { return construction("Relatórios", "Exportação executiva em PDF, planilha e apresentação", "📈") }
