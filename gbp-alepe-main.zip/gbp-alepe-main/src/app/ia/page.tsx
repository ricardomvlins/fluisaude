"use client"

import { useState, useRef, useEffect } from "react"
import { insightsIA } from "@/lib/mock-data"
import { Send, Bot, User, Sparkles, ArrowUpRight, BarChart3, AlertTriangle, Lightbulb, Zap, TrendingUp, RefreshCw, Target, Users, MapPin, Heart, Filter } from "lucide-react"

interface Message { id: string; role: "user" | "ai"; content: string; ts: Date }

const segmentos = [
    { label: "Classe C — Afogados", icon: Users, prompt: "Como conquistar votos na classe C de Afogados? Analise o perfil e sugira abordagens." },
    { label: "Evangélicos — Ibura", icon: Heart, prompt: "Triangulação: eleitores evangélicos do Ibura. Qual a melhor estratégia de aproximação?" },
    { label: "Jovens 18-25", icon: Target, prompt: "Perfil: jovens 18-25, classe B-C, redes sociais ativas. Como converter em votos?" },
    { label: "Comerciantes — Boa Viagem", icon: MapPin, prompt: "Segmento: comerciantes de Boa Viagem. Quais demandas priorizar para ganhar apoio?" },
    { label: "Servidores Públicos", icon: Filter, prompt: "Análise de segmento: servidores públicos. Pontos de dor e proposta de campanha." },
]

const quick = [
    { label: "Resumo do dia", icon: BarChart3, prompt: "Me dê um resumo completo da operação de hoje com métricas e alertas" },
    { label: "Bairros críticos", icon: AlertTriangle, prompt: "Quais bairros estão com queda de apoio? Detalhe ações corretivas." },
    { label: "Plano semanal", icon: Lightbulb, prompt: "Monte um plano estratégico para esta semana com ações diárias prioritárias" },
    { label: "Gerar discurso", icon: Zap, prompt: "Gere um discurso sobre melhorias na saúde pública para evento em Afogados" },
]

const resp: Record<string, string> = {
    "Me dê um resumo completo da operação de hoje com métricas e alertas": `📊 **Resumo Operacional — ${new Date().toLocaleDateString("pt-BR")}**\n\n**Métricas Gerais:**\n• Base ativa: **125.430** eleitores (+5,2% mês)\n• Score médio: **78/100**\n• Taxa de resolução: **81,4%**\n\n**Hoje:**\n• 47 atendimentos realizados\n• 18 demandas pendentes (3 urgentes)\n• 10 eventos na agenda\n\n**⚠️ Alertas:**\n• Afogados: apoio caiu para **38%** (-4%)\n• 3 demandas de saúde vencendo hoje\n• Ibura sem contato há 3 semanas\n\n**✅ Destaques:**\n• Boa Viagem: +200 cadastros esta semana\n• Campanha WhatsApp: 94% de entrega\n• 12 novos apoiadores em Tejipió`,
    "Quais bairros estão com queda de apoio? Detalhe ações corretivas.": `🗺️ **Análise de Bairros em Risco**\n\n**1. Afogados — 38% (↓4%)**\n• 12 demandas pendentes de infraestrutura\n• Líder local sem contato há 2 semanas\n• **Ação:** Visita urgente com líder + mutirão de atendimento\n• **Impacto estimado:** +2% em 7 dias\n\n**2. Ibura — 45% (↓2%)**\n• Baixo engajamento digital (23%)\n• Concorrente realizou evento na semana passada\n• **Ação:** Campanha WhatsApp + evento comunitário\n• **Impacto estimado:** +3% em 14 dias\n\n**3. Torre — 52% (estável, risco)**\n• Sem atividade presencial há 3 semanas\n• 8 demandas de segurança pendentes\n• **Ação:** Reunião com lideranças + resolver demandas\n• **Impacto estimado:** +4% em 10 dias\n\n**💡 Recomendação IA:** Priorizar Afogados esta semana. ROI de tempo/investimento é o melhor entre os 3.`,
    "Monte um plano estratégico para esta semana com ações diárias prioritárias": `🎯 **Plano Estratégico Semanal**\n\n**Segunda-feira**\n• 9h: Reunião de equipe — alinhamento de metas\n• 14h: Visita a Afogados — encontro com 3 lideranças\n• 18h: Disparo WhatsApp Tejipió (1.200 contatos)\n\n**Terça-feira**\n• 9h: Atendimentos prioritários (6 demandas urgentes)\n• 15h: Gravação de vídeo — tema saúde pública\n• 19h: Evento comunitário Ibura\n\n**Quarta-feira**\n• 10h: Porta a porta Afogados (meta: 50 contatos)\n• 14h: Análise de dados — relatório de sentimento\n• 20h: Live temática — saúde e educação\n\n**Quinta-feira**\n• 9h: Follow-up leads da semana\n• 14h: Reunião com comerciantes Boa Viagem\n• 17h: Campanha segmentada classe C\n\n**Sexta-feira**\n• 10h: Resolução de demandas pendentes\n• 14h: Relatório semanal + planejamento\n• 16h: Disparo de pesquisa de satisfação\n\n**Meta da semana:**\n✅ +150 cadastros · +2% Afogados · 80% demandas resolvidas`,
    "Gere um discurso sobre melhorias na saúde pública para evento em Afogados": `📝 **Discurso — Saúde para Afogados**\n_(2-3 minutos · tom empático e propositivo)_\n\n---\n\n_"Boa noite, Afogados!_\n\n_Eu sei que quando a gente fala de saúde aqui no bairro, todo mundo tem uma história pra contar. A fila que não anda, o remédio que falta, o posto que fecha cedo demais._\n\n_Nos últimos 6 meses, recebemos **156 demandas** só sobre saúde. E eu quero que vocês saibam: **cada uma foi ouvida**._\n\n_Já conseguimos:_\n_• Ampliar o horário de **3 postos de saúde**_\n_• Atender **12 mil famílias** em mutirões_\n_• Reduzir o tempo de espera em **40%**_\n\n_Mas eu sei que ainda não é suficiente. Por isso, esta semana estamos lançando o programa **Saúde de Porta em Porta** — uma equipe que vai até você, no seu horário, no seu bairro._\n\n_Saúde não é favor. É direito. E nós vamos garantir isso juntos."_\n\n---\n**Dicas de apresentação:**\n• Fazer pausas nos números\n• Olhar para diferentes lados da plateia\n• Citar nomes de líderes locais presentes`,
    "Como conquistar votos na classe C de Afogados? Analise o perfil e sugira abordagens.": `🔺 **Triangulação — Classe C · Afogados**\n\n**Perfil do Segmento:**\n• ~4.200 eleitores (33% da base local)\n• Renda familiar: R$ 2.500-5.000\n• Idade média: 35-50 anos\n• 68% mulheres chefes de família\n• Principais preocupações: saúde, emprego, transporte\n\n**Canais Efetivos:**\n• WhatsApp (89% de penetração)\n• Eventos presenciais em igrejas e associações\n• Rádio comunitária\n\n**Estratégia de 3 Frentes:**\n\n**1. Demanda concreta** (curto prazo)\n• Resolver 12 demandas de infraestrutura pendentes\n• Mutirão de documentos e serviços\n• Impacto: reconhecimento imediato\n\n**2. Presença constante** (médio prazo)\n• 1 visita semanal com liderança local\n• Grupo WhatsApp ativo com atualizações\n• Impacto: construção de confiança\n\n**3. Proposta tangível** (longo prazo)\n• Programa de capacitação profissional\n• Parceria com comércios locais\n• Impacto: fidelização\n\n**Projeção:** +5% de apoio em 30 dias se executar frentes 1 e 2 simultaneamente\n**ROI:** Alto — segmento com maior potencial de conversão no bairro`,
    "Triangulação: eleitores evangélicos do Ibura. Qual a melhor estratégia de aproximação?": `🔺 **Triangulação — Evangélicos · Ibura**\n\n**Perfil do Segmento:**\n• ~2.800 eleitores identificados\n• 12 igrejas mapeadas (4 com +500 membros)\n• Lideranças-chave: Pastor Marcos (Assembleia), Pastora Ana (Batista)\n• Valores: família, segurança, educação, empreendedorismo\n\n**O que NÃO fazer:**\n⛔ Prometer cargos religiosos\n⛔ Instrumentalizar cultos\n⛔ Posicionamento vago sobre valores\n\n**Estratégia recomendada:**\n\n**1. Porta de entrada: Ação Social**\n• Parceria com igrejas para cestas básicas\n• Arrecadação para reforma de espaço comunitário\n• Resultado esperado: abertura para diálogo\n\n**2. Agenda compartilhada:**\n• Participar de eventos sociais (não cultos)\n• Apoiar projetos de juventude das igrejas\n• Pauta de segurança no bairro (interesse comum)\n\n**3. Comunicação respeitosa:**\n• WhatsApp com conteúdo de valor (não político)\n• Vídeo-depoimento com líderes que já apoiam\n• Tom: servir, não pedir\n\n**Projeção:** +8% em 45 dias com abordagem correta\n**Risco:** Aproximação mal feita pode gerar efeito contrário (-3%)`,
    "Perfil: jovens 18-25, classe B-C, redes sociais ativas. Como converter em votos?": `🔺 **Triangulação — Jovens 18-25 · Classe B-C**\n\n**Perfil:**\n• ~8.500 eleitores nesta faixa\n• 72% em redes sociais (Instagram, TikTok)\n• 45% primeiro voto\n• Preocupações: emprego, educação, cultura, meio ambiente\n• Baixa confiança em política tradicional\n\n**Erro comum:** Tratar como "público secundário"\n**Realidade:** É o segmento com maior potencial de viralização\n\n**Estratégia:**\n\n**1. Conteúdo digital (imediato)**\n• 3 Reels/semana: bastidores, dados visuais, humor leve\n• 1 Live/semana: tema relevante + convidado jovem\n• Linguagem: direta, sem jargão político\n\n**2. Presença em território jovem**\n• Eventos em universidades e centros culturais\n• Hackathon de soluções para o bairro\n• Programa de estágio/mentoria\n\n**3. Participação real**\n• Conselho jovem consultivo (10 membros)\n• Orçamento participativo para projetos jovens\n• Impacto: senso de pertencimento\n\n**Métricas-alvo:**\n• +2.000 seguidores em 30 dias\n• +500 cadastros via redes\n• 23% → 45% de engajamento\n\n**⚡ Quick win:** Sorteio de ingresso para evento cultural via cadastro`,
    "Segmento: comerciantes de Boa Viagem. Quais demandas priorizar para ganhar apoio?": `🔺 **Triangulação — Comerciantes · Boa Viagem**\n\n**Perfil:**\n• ~800 estabelecimentos mapeados\n• 340 já cadastrados na base\n• Apoio atual: 72% (alto, mas instável)\n• Setores: alimentação (35%), varejo (28%), serviços (37%)\n\n**Top 5 Demandas (por frequência):**\n1. **Segurança** — 47% citam como prioridade #1\n2. **Estacionamento** — 32% pedem vagas rotativas\n3. **Impostos** — 28% querem renegociação IPTU\n4. **Infraestrutura** — 23% reclamam de calçadas\n5. **Eventos** — 19% querem feiras e festivais\n\n**Ações priorizadas:**\n\n**Semana 1:** Reunião com associação comercial\n• Apresentar pauta de segurança\n• Colher novas demandas\n\n**Semana 2:** Operação visível de segurança\n• Ronda noturna com GCM\n• Iluminação de pontos críticos\n\n**Semana 3:** Evento comercial\n• Feira de negócios locais\n• Networking com lideranças\n\n**Projeção:** Manter 72%+ e converter 50 novos apoiadores\n**Alerta:** Concorrente marcou evento na região para o dia 15`,
    "Análise de segmento: servidores públicos. Pontos de dor e proposta de campanha.": `🔺 **Triangulação — Servidores Públicos**\n\n**Perfil:**\n• ~3.200 eleitores identificados\n• Distribuídos em 15+ bairros\n• Áreas: educação (40%), saúde (25%), administrativo (35%)\n• Renda: R$ 3.000-8.000\n• Apoio médio: 61%\n\n**Pontos de Dor:**\n1. Plano de carreira defasado\n2. Condições de trabalho (equipamentos, estrutura)\n3. Falta de valorização profissional\n4. Preocupação com reforma administrativa\n5. Saúde mental e sobrecarga\n\n**Proposta de Campanha:**\n\n**Slogan:** "Quem serve o público merece ser servido"\n\n**Ações:**\n• Audiência pública sobre plano de carreira\n• Canal direto para demandas de servidores\n• Programa de saúde mental no trabalho\n• Reconhecimento público: "Servidor Destaque"\n\n**Comunicação:**\n• E-mail segmentado (400+ cadastros)\n• Grupo WhatsApp exclusivo\n• Café da manhã mensal com servidores\n\n**Projeção:** 61% → 74% em 60 dias`,
}

export default function IAPage() {
    const [msgs, setMsgs] = useState<Message[]>([
        { id: "w", role: "ai", content: "Olá! Sou o **Operah IA**.\n\nPosso fazer **triangulação de perfis**, analisar segmentos, gerar discursos e montar estratégias de campanha.\n\n💡 **Dica:** Use os botões de segmento abaixo para análises detalhadas de como conquistar votos por perfil.", ts: new Date() }
    ])
    const [input, setInput] = useState("")
    const [typing, setTyping] = useState(false)
    const ref = useRef<HTMLDivElement>(null)

    useEffect(() => { ref.current?.scrollTo({ top: ref.current.scrollHeight, behavior: "smooth" }) }, [msgs, typing])

    const send = (text: string) => {
        if (!text.trim() || typing) return
        setMsgs(p => [...p, { id: Date.now().toString(), role: "user", content: text, ts: new Date() }])
        setInput(""); setTyping(true)
        setTimeout(() => {
            const r = resp[text] || `🔺 **Análise: "${text}"**\n\n**Dados da base:**\n• 125.430 eleitores ativos\n• 42 bairros mapeados\n• Score médio: 78/100\n\n**Recomendação:**\nPara uma análise mais precisa, selecione um segmento específico (classe social, bairro, faixa etária, profissão ou religião).\n\n**Triangulação disponível para:**\n• Classe social + bairro\n• Idade + interesse\n• Profissão + demanda\n• Religião + território\n\nDeseja aprofundar alguma combinação?`
            setMsgs(p => [...p, { id: (Date.now() + 1).toString(), role: "ai", content: r, ts: new Date() }])
            setTyping(false)
        }, 1500 + Math.random() * 1000)
    }

    return (
        <div className="p-6 lg:p-8 h-[calc(100vh-3rem)] flex gap-5 page-enter max-w-[1440px] mx-auto">
            <div className="flex-1 flex flex-col min-w-0">
                <div className="flex items-center gap-3 mb-4">
                    <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-[#bf5af2] to-[#5e5ce6] flex items-center justify-center shadow-lg shadow-[#bf5af2]/10 animate-float">
                        <Bot className="h-5 w-5 text-white" />
                    </div>
                    <div>
                        <h1 className="text-[24px] font-bold tracking-tight">IA Política</h1>
                        <p className="text-[12px] text-muted-foreground flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-[#30d158] animate-dot-pulse" /> Triangulação ativa</p>
                    </div>
                </div>

                <div className="bg-card rounded-2xl border flex-1 flex flex-col overflow-hidden">
                    <div ref={ref} className="flex-1 overflow-y-auto p-5 space-y-4">
                        {msgs.map(m => (
                            <div key={m.id} className={`flex gap-3 animate-appear ${m.role === "user" ? "flex-row-reverse" : ""}`} style={{ animationDuration: "0.3s" }}>
                                <div className={`h-7 w-7 rounded-xl shrink-0 flex items-center justify-center ${m.role === "ai" ? "bg-gradient-to-br from-[#bf5af2] to-[#5e5ce6]" : "bg-muted"}`}>
                                    {m.role === "ai" ? <Sparkles className="h-3.5 w-3.5 text-white" /> : <User className="h-3.5 w-3.5" />}
                                </div>
                                <div className={`max-w-[75%] rounded-2xl px-4 py-3 ${m.role === "ai" ? "bg-muted border" : "bg-primary text-primary-foreground"}`}>
                                    <div className="text-[13px] leading-relaxed whitespace-pre-wrap">
                                        {m.content.split("\n").map((line, i) => {
                                            const html = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/_(.*?)_/g, '<em>$1</em>')
                                            return <p key={i} className="mb-0.5 last:mb-0" dangerouslySetInnerHTML={{ __html: html }} />
                                        })}
                                    </div>
                                    <p className={`text-[10px] mt-2 opacity-40`}>{m.ts.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}</p>
                                </div>
                            </div>
                        ))}
                        {typing && (
                            <div className="flex gap-3 animate-fade-in">
                                <div className="h-7 w-7 rounded-xl bg-gradient-to-br from-[#bf5af2] to-[#5e5ce6] flex items-center justify-center"><Sparkles className="h-3.5 w-3.5 text-white animate-pulse" /></div>
                                <div className="bg-muted border rounded-2xl px-4 py-3 flex gap-1.5">
                                    {[0, 150, 300].map(d => <span key={d} className="h-2 w-2 rounded-full bg-muted-foreground/30 animate-bounce" style={{ animationDelay: `${d}ms` }} />)}
                                </div>
                            </div>
                        )}
                    </div>

                    <div className="px-4 py-2 border-t">
                        <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5">Triangulação por Segmento</p>
                        <div className="flex gap-1.5 overflow-x-auto pb-1">
                            {segmentos.map(s => (
                                <button key={s.label} onClick={() => send(s.prompt)}
                                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#bf5af2]/10 text-[#bf5af2] text-[11px] font-semibold hover:bg-[#bf5af2]/20 transition-all whitespace-nowrap shrink-0">
                                    <s.icon className="h-3 w-3" />{s.label}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="px-4 py-1.5 border-t">
                        <div className="flex gap-1.5 overflow-x-auto">
                            {quick.map(a => (
                                <button key={a.label} onClick={() => send(a.prompt)}
                                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-medium text-muted-foreground hover:text-foreground hover:border-foreground/20 transition-all whitespace-nowrap shrink-0">
                                    <a.icon className="h-3 w-3" />{a.label}
                                </button>
                            ))}
                        </div>
                    </div>

                    <form onSubmit={e => { e.preventDefault(); send(input) }} className="p-3 border-t flex gap-2">
                        <input value={input} onChange={e => setInput(e.target.value)} placeholder="Pergunte ao Operah IA ou descreva um segmento para triangulação..."
                            className="flex-1 h-10 px-4 bg-muted border rounded-full text-[13px] placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-chart-2/30" disabled={typing} />
                        <button type="submit" disabled={typing || !input.trim()}
                            className="h-10 w-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:opacity-90 transition-opacity disabled:opacity-30">
                            <Send className="h-4 w-4" />
                        </button>
                    </form>
                </div>
            </div>

            <div className="hidden xl:flex flex-col w-72 gap-4 shrink-0">
                <div className="bg-card rounded-2xl border p-5">
                    <h3 className="text-[13px] font-semibold flex items-center gap-2 mb-3"><TrendingUp className="h-3.5 w-3.5 text-chart-2" /> Insights Ativos</h3>
                    <div className="space-y-1">
                        {insightsIA.map(ins => (
                            <div key={ins.id} onClick={() => send(ins.acao || ins.titulo)} className="p-2.5 rounded-xl hover:bg-muted transition-all cursor-pointer group">
                                <div className="flex items-center gap-2 mb-0.5">
                                    <span className={`h-1.5 w-1.5 rounded-full ${ins.tipo === "alerta" ? "bg-destructive" : ins.tipo === "oportunidade" ? "bg-[#30d158]" : "bg-chart-1"}`} />
                                    <span className="text-[12px] font-medium">{ins.titulo}</span>
                                </div>
                                <p className="text-[11px] text-muted-foreground leading-relaxed ml-3.5 line-clamp-2">{ins.descricao}</p>
                            </div>
                        ))}
                    </div>
                </div>
                <div className="bg-card rounded-2xl border p-5 flex-1">
                    <h3 className="text-[13px] font-semibold flex items-center gap-2 mb-3"><RefreshCw className="h-3.5 w-3.5 text-chart-1" /> Capacidades IA</h3>
                    <div className="space-y-2 text-[12px] text-muted-foreground">
                        {["Triangulação de perfis por segmento", "Análise territorial com dados", "Geração de discursos personalizados", "Planos de campanha segmentados", "Projeção de impacto por ação", "Monitoramento de crises", "Recomendação de visitas", "Análise preditiva de apoio"].map((c, i) => (
                            <div key={i} className="flex items-center gap-2 py-0.5"><span className="h-1.5 w-1.5 rounded-full bg-chart-2/40 shrink-0" />{c}</div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    )
}
