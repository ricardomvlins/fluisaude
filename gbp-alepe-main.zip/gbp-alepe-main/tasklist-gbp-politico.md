# GBP Político — Tasklist Completa

## ✅ Concluído (Operah — Sessão Atual)

### Estrutura e Arquitetura
- [x] Setup Next.js 15 + React 19 + Tailwind CSS v4
- [x] Sistema de rotas com 24 páginas funcionais
- [x] SidebarProvider com collapse offcanvas (desaparece completo)
- [x] TopHeader fixo (nunca se move)
- [x] AuthGuard com proteção de rotas por token
- [x] ThemeProvider com dark/light mode toggle
- [x] Toast notification system (Framer Motion, auto-dismiss 3s)
- [x] Layout root com h-svh overflow-hidden (viewport locked)

### Branding
- [x] Logo ALEPE no sidebar + login
- [x] "GBP Político — Gestão de Base Política" como título
- [x] "powered by operah & alepe" no footer do sidebar
- [x] Renomeado "Copiloto IA" → "Operah IA"
- [x] Fonte Inter como padrão, SF Pro no branding
- [x] Metadata SEO (title, description)

### Dashboard (`/`)
- [x] Saudação dinâmica (Bom dia/Boa tarde/Boa noite)
- [x] 4 KPIs com stagger animation (eleitores, lideranças, demandas, satisfação)
- [x] Gráficos Recharts com cores temáticas (light/dark)
- [x] Feed de atividades recentes
- [x] Card Operah IA com insights
- [x] Responsive grid (1→2→4 colunas)

### CRM Eleitoral (`/crm`)
- [x] Tabela de eleitores com dados mockados realistas
- [x] Sort por coluna (nome, bairro, segmento, apoio)
- [x] Export CSV funcional (download real)
- [x] Copiar telefone/email pro clipboard com toast
- [x] Filtros por segmento (chips toggle)
- [x] Painel de perfil do eleitor
- [x] Botão "Ver Perfil Completo" com toast

### Mapa Eleitoral (`/mapa`)
- [x] Mapa Leaflet funcional centrado em Recife
- [x] Zonas de calor por bairro
- [x] Ranking lateral de bairros com % de apoio
- [x] Painel de detalhes ao selecionar bairro
- [x] Botões "Gerar Campanha" e "Exportar Dados" funcionais
- [x] Toggle de camadas (apoiadores, demandas, lideranças)
- [x] Busca de bairros

### Atendimentos (`/atendimentos`)
- [x] Kanban 5 colunas (Aberto→Triagem→Andamento→Aguardando→Concluído)
- [x] Drag-and-drop com toast feedback
- [x] Cards com prioridade, protocolo, canal, responsável, prazo
- [x] Busca funcional
- [x] Botão "Novo" com toast
- [x] Stats bar (pendentes, urgentes, concluídos)
- [x] Colunas com scroll vertical independente

### Demandas (`/demandas`)
- [x] Gráfico por categoria (Infra, Saúde, Educação, Segurança)
- [x] Lista de demandas recentes clicáveis
- [x] Botão "Nova Demanda" com toast
- [x] Tooltip do gráfico theme-aware

### Agenda (`/agenda`)
- [x] Calendário visual do mês atual
- [x] Lista de compromissos com tipo (reunião, visita, comício, live)
- [x] Botão "Novo Evento" com toast
- [x] Navegação de mês com feedback

### Comunicação (`/comunicacao`)
- [x] Página funcional com layout

### Operah IA (`/ia`)
- [x] Chat interativo com mensagens formatadas
- [x] Segmentos pré-definidos (Jovens, Classe C/D, Evangélicos, etc.)
- [x] Triangulação de perfis por IA
- [x] Input com envio funcional
- [x] Branding "Operah IA"

### Estratégia (`/estrategia`)
- [x] Análise SWOT (Forças, Fraquezas, Oportunidades, Ameaças)
- [x] Cenários eleitorais clicáveis (Pessimista, Base, Otimista)
- [x] Lista de prioridades clicáveis com meta

### Relatórios (`/relatorios`)
- [x] Página funcional

### Pesquisas (`/pesquisas`)
- [x] Página funcional

### Configurações (`/configuracoes`)
- [x] Aba Perfil: nome, partido, número, cargo, cidade, estado, bio, foto, redes sociais
- [x] Aba Conta: token de acesso, 2FA, sessões ativas
- [x] Aba Notificações: 7 toggles configuráveis
- [x] Aba Plano: Pro com métricas de uso
- [x] Botão "Salvar" com loading animation
- [x] "Contatar Operah" com toast

### Login (`/login`)
- [x] Layout split (form + features panel)
- [x] Input de token com eye toggle
- [x] Loading animation no botão
- [x] 3 features highlights (CRM, IA, Segurança)
- [x] Branding institucional

### Header
- [x] SidebarTrigger que esconde sidebar completamente
- [x] Busca global com fundo muted
- [x] Notificações com badge, mark as read, "Marcar todas"
- [x] Dropdown de perfil (nome, partido, cargo, perfil, config, logout)
- [x] Theme toggle (dark/light)

### Animações e Performance
- [x] Blur-in animations (appear, fade-in, slide-right, scale-in)
- [x] Spring curves (cubic-bezier 0.22, 1, 0.36, 1)
- [x] Stagger com 40ms delay por child
- [x] Framer Motion no dashboard, toast, IA
- [x] Lenis removido (performance nativa)
- [x] Build com 0 erros, 24 rotas estáticas

---

## 🔲 Próximos Passos (O que a Operah pode entregar)

### Backend e Integração
- [ ] API REST com .NET / Node.js (autenticação, CRUD, roles)
- [ ] Banco de dados PostgreSQL (eleitores, demandas, atendimentos)
- [ ] Autenticação real com JWT + refresh token
- [ ] Sistema de permissões por plano (básico, pro, enterprise)
- [ ] Integração com WhatsApp Business API
- [ ] Webhook para notificações em tempo real

### CRM Avançado
- [ ] Cadastro completo de eleitor (formulário com 20+ campos)
- [ ] Upload de foto do eleitor
- [ ] Importação em massa (CSV/Excel)
- [ ] Tags e grupos customizáveis
- [ ] Timeline de interações por eleitor
- [ ] Geolocalização no cadastro (bairro, rua, CEP)

### Mapa Avançado
- [ ] Integração com API de geolocalização real
- [ ] Camadas com dados reais (IBGE, TSE)
- [ ] Zonas eleitorais e seções de votação
- [ ] Heatmap de demandas sobrepostas
- [ ] Filtro por zona, seção e bairro

### IA de Produção
- [ ] Integração com GPT-4 / Claude API
- [ ] Geração de discursos personalizados
- [ ] Análise de sentimento de redes sociais
- [ ] Sugestão automática de pauta semanal
- [ ] Resumo diário por e-mail
- [ ] Triangulação cruzada de dados reais

### Comunicação
- [ ] Disparo de SMS em massa
- [ ] Templates de WhatsApp
- [ ] E-mail marketing integrado
- [ ] Segmentação automática de público
- [ ] Métricas de entrega e abertura

### Relatórios
- [ ] Exportação PDF com layout profissional
- [ ] Relatório de prestação de contas
- [ ] Gráficos de evolução mensal
- [ ] Comparativo entre períodos
- [ ] Dashboard de campanha em tempo real

### Infraestrutura
- [ ] Deploy em AWS / Vercel com CI/CD
- [ ] Domínio customizado (.com.br)
- [ ] SSL, WAF, proteção DDoS
- [ ] Backup automático diário
- [ ] Monitoramento 24/7 (uptime, performance)
- [ ] LGPD compliance (dados de eleitores)

### Mobile
- [ ] PWA (Progressive Web App) para acesso mobile
- [ ] Push notifications nativas
- [ ] App nativo React Native (fase futura)

### Administrativo
- [ ] Painel admin para equipe Operah gerenciar clientes
- [ ] Multi-tenant (cada político tem sua instância)
- [ ] Métricas de uso por cliente
- [ ] Sistema de billing e planos
